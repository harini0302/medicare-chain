import { BrowserRouter, Routes, Route } from "react-router-dom";
import LandingPage from "./components/LandingPage";
import ManufacturerDashboard from "./components/Manufacturer/ManufacturerDashboard";
import Inventory from "./components/Manufacturer/Inventory";
// import DistributorDashboard from "./components/distributor/DistributorDashboard";
// import WholesalerDashboard from "./components/wholesaler/WholesalerDashboard";
// import RetailerDashboard from "./components/retailer/RetailerDashboard";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Default Landing Page */}
        <Route path="/" element={<LandingPage />} />

        {/* Role-Based Dashboards */}
        <Route path="/manufacturer/dashboard" element={<ManufacturerDashboard />} />
        <Route path="/manufacturer/inventory" element={<Inventory />} />
        {/* <Route path="/distributor/dashboard" element={<DistributorDashboard />} />
        <Route path="/wholesaler/dashboard" element={<WholesalerDashboard />} />
        <Route path="/retailer/dashboard" element={<RetailerDashboard />} /> */}
      </Routes>
    </BrowserRouter>
  );
}
export default App;
