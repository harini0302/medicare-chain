import React, { useState, useMemo, useCallback, useEffect } from 'react';
import './Inventory.css';
import Navbar from './Navbar';

const Inventory = () => {
  const [activeTab, setActiveTab] = useState('ManufacturerDashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(50);
  const [inventoryData, setInventoryData] = useState([]);
  const [newRows, setNewRows] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [skuCounter, setSkuCounter] = useState(1);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [editMode, setEditMode] = useState(false);
  const [editingCell, setEditingCell] = useState(null);
  const [editValue, setEditValue] = useState('');

  // Category options with their respective units
  const categoryOptions = [
    { 
      value: 'Tablets', 
      label: 'Tablets',
      units: ['tablet', 'strip', 'bottle']
    },
    { 
      value: 'Capsules', 
      label: 'Capsules',
      units: ['capsule', 'strip', 'bottle']
    },
    { 
      value: 'Injections', 
      label: 'Injections',
      units: ['vial', 'ampoule', 'syringe']
    },
    { 
      value: 'Syrups', 
      label: 'Syrups',
      units: ['bottle', 'ml']
    },
    { 
      value: 'Ointments', 
      label: 'Ointments',
      units: ['tube', 'jar', 'g']
    },
    { 
      value: 'Inhalers', 
      label: 'Inhalers',
      units: ['inhaler', 'puff']
    },
    { 
      value: 'Drops', 
      label: 'Drops',
      units: ['bottle', 'drop', 'ml']
    },
    { 
      value: 'Sprays', 
      label: 'Sprays',
      units: ['bottle', 'spray', 'ml']
    },
    { 
      value: 'Powders', 
      label: 'Powders',
      units: ['sachet', 'g', 'bottle']
    },
    { 
      value: 'Creams', 
      label: 'Creams',
      units: ['tube', 'jar', 'g']
    }
  ];

  // Stock level options for filtering
  const stockLevelOptions = [
    { value: '', label: 'All Stock Levels' },
    { value: 'high', label: 'High Stock' },
    { value: 'medium', label: 'Medium Stock' },
    { value: 'low', label: 'Low Stock' },
    { value: 'out', label: 'Out of Stock' }
  ];

  // Function to generate SKU based on category name and counter
  const generateSKU = (category = 'Tablets') => {
    const categoryName = category.toUpperCase().replace(/\s+/g, '');
    const timestamp = Date.now().toString().slice(-4);
    const counter = skuCounter.toString().padStart(3, '0');
    
    return `${categoryName}-${counter}-${timestamp}`;
  };

  const initializeNewRow = (category = 'Tablets') => {
    const newSku = generateSKU(category);
    const selectedCategory = categoryOptions.find(cat => cat.value === category) || categoryOptions[0];
    const defaultUnit = selectedCategory.units[0];
    
    setSkuCounter(prev => prev + 1);
    
    return {
      id: 'new-' + Date.now(),
      sku: newSku,
      name: '',
      description: '',
      unit_price: 0,
      tax_rate: 0,
      stock_qty: 0,
      unit: defaultUnit,
      mfg_date: new Date().toISOString().split('T')[0],
      expiry_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: category,
      isNew: true
    };
  };

  const fetchInventoryData = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/medicines');
      const data = await response.json();
      setInventoryData(data);
      
      // Initialize SKU counter based on existing data
      if (data.length > 0) {
        const maxSkuNumber = Math.max(...data.map(item => {
          const skuParts = item.sku.split('-');
          return parseInt(skuParts[1]) || 0;
        }).filter(num => !isNaN(num)));
        
        setSkuCounter(maxSkuNumber + 1);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveMedicine = async (medicineData) => {
    try {
      const response = await fetch('/api/medicines', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(medicineData),
      });
      
      if (response.ok) {
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error saving medicine:', error);
      return false;
    }
  };

  const updateMedicine = async (medicineData) => {
    try {
      const response = await fetch(`/api/medicines/${medicineData.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(medicineData),
      });
      
      if (response.ok) {
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error updating medicine:', error);
      return false;
    }
  };

  const deleteMedicines = async (medicineIds) => {
    try {
      const deletePromises = medicineIds.map(id => 
        fetch(`/api/medicines/${id}`, {
          method: 'DELETE',
        })
      );
      
      const results = await Promise.all(deletePromises);
      return results.every(result => result.ok);
    } catch (error) {
      console.error('Error deleting medicines:', error);
      return false;
    }
  };

  const saveAllNewMedicines = async () => {
    try {
      const savePromises = newRows.map(medicine => saveMedicine(medicine));
      const results = await Promise.all(savePromises);
      
      if (results.every(result => result)) {
        await fetchInventoryData();
        setNewRows([]);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error saving medicines:', error);
      return false;
    }
  };

  useEffect(() => {
    fetchInventoryData();
  }, []);

  const getStockLevel = (quantity) => {
    if (quantity === 0) return 'Out of Stock';
    if (quantity < 50) return 'Low';
    if (quantity < 200) return 'Medium';
    return 'High';
  };

  const getStockLevelClass = (quantity) => {
    if (quantity === 0) return 'out-of-stock';
    if (quantity < 50) return 'low';
    if (quantity < 200) return 'medium';
    return 'high';
  };

  const filteredData = useMemo(() => {
    let filtered = inventoryData.filter(item => {
      const matchesSearch = !searchQuery || 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sku.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = !selectedCategory || item.category === selectedCategory;

      // Stock level filtering
      let matchesStock = true;
      if (sortBy === 'stock_level') {
        const stockLevel = getStockLevel(item.stock_qty).toLowerCase().replace(' ', '');
        matchesStock = stockLevel.includes(sortOrder);
      }

      return matchesSearch && matchesCategory && matchesStock;
    });

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue, bValue;
      
      switch (sortBy) {
        case 'name':
          aValue = a.name.toLowerCase();
          bValue = b.name.toLowerCase();
          break;
        case 'price':
          aValue = a.unit_price;
          bValue = b.unit_price;
          break;
        case 'stock':
          aValue = a.stock_qty;
          bValue = b.stock_qty;
          break;
        case 'stock_level':
          // For stock level, we sort by quantity but filter by level
          aValue = a.stock_qty;
          bValue = b.stock_qty;
          break;
        default:
          aValue = a.name.toLowerCase();
          bValue = b.name.toLowerCase();
      }

      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortOrder === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else {
        return sortOrder === 'asc' ? aValue - bValue : bValue - aValue;
      }
    });

    return filtered;
  }, [inventoryData, searchQuery, selectedCategory, sortBy, sortOrder]);

  const formatCurrency = (amount) => {
    return `$${parseFloat(amount).toFixed(2)}`;
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1);
  };

  const handleSortChange = (newSortBy) => {
    if (sortBy === newSortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(newSortBy);
      setSortOrder('asc');
    }
  };

  const handleStockLevelFilter = (level) => {
    if (level === '') {
      // Reset to normal sorting
      setSortBy('name');
      setSortOrder('asc');
    } else {
      setSortBy('stock_level');
      setSortOrder(level);
    }
  };

  const handleAddMedicine = () => {
    setNewRows(prev => [...prev, initializeNewRow()]);
  };

  const handleSaveAll = async () => {
    const success = await saveAllNewMedicines();
    if (success) {
      alert('All medicines saved successfully!');
    } else {
      alert('Error saving some medicines. Please try again.');
    }
  };

  const handleCancelAll = () => {
    setNewRows([]);
  };

  const handleRemoveNewRow = (id) => {
    setNewRows(prev => prev.filter(row => row.id !== id));
  };

  // Selection handlers
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      const allIds = new Set([...visibleData.map(item => item.id), ...newRows.map(row => row.id)]);
      setSelectedRows(allIds);
    } else {
      setSelectedRows(new Set());
    }
  };

  const handleSelectRow = (id) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedRows(newSelected);
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    
    const confirmDelete = window.confirm(
      `Are you sure you want to delete ${selectedRows.size} selected medicine(s)? This action cannot be undone.`
    );
    
    if (confirmDelete) {
      // Separate existing medicines and new rows
      const existingMedicines = Array.from(selectedRows).filter(id => !id.toString().startsWith('new-'));
      const newRowIds = Array.from(selectedRows).filter(id => id.toString().startsWith('new-'));
      
      let success = true;
      
      // Delete existing medicines from server
      if (existingMedicines.length > 0) {
        success = await deleteMedicines(existingMedicines);
      }
      
      // Remove new rows from local state
      if (newRowIds.length > 0) {
        setNewRows(prev => prev.filter(row => !newRowIds.includes(row.id)));
      }
      
      if (success) {
        if (existingMedicines.length > 0) {
          await fetchInventoryData();
        }
        setSelectedRows(new Set());
        alert('Selected medicines deleted successfully!');
      } else {
        alert('Error deleting medicines. Please try again.');
      }
    }
  };

  // Inline editing handlers
  const handleCellEdit = (medicineId, field, value) => {
    setEditingCell({ medicineId, field });
    setEditValue(value);
  };

  const handleCellSave = async () => {
    if (!editingCell) return;

    // Check if it's a new row or existing medicine
    if (editingCell.medicineId.toString().startsWith('new-')) {
      // Update new row
      setNewRows(prev => 
        prev.map(row => 
          row.id === editingCell.medicineId 
            ? { ...row, [editingCell.field]: editValue }
            : row
        )
      );
    } else {
      // Update existing medicine
      const updatedData = inventoryData.map(item => 
        item.id === editingCell.medicineId 
          ? { ...item, [editingCell.field]: editValue }
          : item
      );

      const medicineToUpdate = inventoryData.find(item => item.id === editingCell.medicineId);
      if (medicineToUpdate) {
        const updatedMedicine = { ...medicineToUpdate, [editingCell.field]: editValue };
        const success = await updateMedicine(updatedMedicine);
        
        if (success) {
          setInventoryData(updatedData);
        } else {
          alert('Error updating medicine. Please try again.');
          return;
        }
      }
    }

    setEditingCell(null);
    setEditValue('');
  };

  const handleCellCancel = () => {
    setEditingCell(null);
    setEditValue('');
  };

  // Separate component for editable rows with local state
  const EditableNewRow = React.memo(({ medicine, onUpdate, onRemove }) => {
    const [localData, setLocalData] = useState(medicine);

    // Get available units for the selected category
    const getAvailableUnits = (category) => {
      const categoryData = categoryOptions.find(cat => cat.value === category);
      return categoryData ? categoryData.units : ['tablet'];
    };

    useEffect(() => {
      setLocalData(medicine);
    }, [medicine]);

    const handleFieldChange = (field, value) => {
      const updatedData = { ...localData, [field]: value };

      if (field === 'category') {
        // Auto-update unit + SKU when category changes
        const availableUnits = getAvailableUnits(value);
        updatedData.unit = availableUnits[0];
        updatedData.sku = generateSKU(value);
        setSkuCounter(prev => prev + 1);

        // Immediately update parent since dependent fields change
        onUpdate(medicine.id, updatedData);
      }

      setLocalData(updatedData);
    };

    // Update parent only when user finishes typing (blur)
    const handleFieldBlur = () => {
      onUpdate(medicine.id, localData);
    };

    const handleRegenerateSKU = () => {
      const newSku = generateSKU(localData.category);
      const newData = { ...localData, sku: newSku };
      setLocalData(newData);
      onUpdate(medicine.id, newData);
      setSkuCounter(prev => prev + 1);
    };

    const availableUnits = getAvailableUnits(localData.category);

    return (
      <tr className="editing-new-row">
        {/* Checkbox - Only show in edit mode */}
        {editMode && (
          <td className="checkbox-cell">
            <input
              type="checkbox"
              checked={selectedRows.has(medicine.id)}
              onChange={() => handleSelectRow(medicine.id)}
            />
          </td>
        )}

        {/* SKU */}
        <td className="editable-cell">
          <div className="sku-input-group">
            <input
              type="text"
              value={localData.sku || ""}
              onChange={(e) => handleFieldChange("sku", e.target.value)}
              onBlur={handleFieldBlur}
              placeholder="Auto-generated SKU"
              className="sku-input"
            />
            <button 
              type="button"
              className="regenerate-sku-btn"
              onClick={handleRegenerateSKU}
              title="Regenerate SKU"
            >
              🔄
            </button>
          </div>
        </td>

        {/* Medicine Name */}
        <td className="editable-cell">
          <input
            type="text"
            value={localData.name || ""}
            onChange={(e) => handleFieldChange("name", e.target.value)}
            onBlur={handleFieldBlur}
            placeholder="Enter Product Name"
            className="full-width-input"
          />
        </td>

        {/* Description */}
        <td className="editable-cell">
          <input
            type="text"
            value={localData.description || ""}
            onChange={(e) => handleFieldChange("description", e.target.value)}
            onBlur={handleFieldBlur}
            placeholder="Enter Description"
            className="full-width-input"
          />
        </td>

        {/* Unit Price */}
        <td className="editable-cell">
          <input
            type="number"
            step="0.01"
            min="0"
            value={localData.unit_price || ""}
            onChange={(e) => handleFieldChange("unit_price", parseFloat(e.target.value) || 0)}
            onBlur={handleFieldBlur}
            placeholder="0.00"
            className="full-width-input"
          />
        </td>

        {/* Tax Rate */}
        <td className="editable-cell">
          <input
            type="number"
            step="0.1"
            min="0"
            max="100"
            value={localData.tax_rate || ""}
            onChange={(e) => handleFieldChange("tax_rate", parseFloat(e.target.value) || 0)}
            onBlur={handleFieldBlur}
            placeholder="0.0"
            className="full-width-input"
          />
        </td>

        {/* Stock Quantity */}
        <td className="editable-cell">
          <input
            type="number"
            min="0"
            value={localData.stock_qty || ""}
            onChange={(e) => handleFieldChange("stock_qty", parseInt(e.target.value) || 0)}
            onBlur={handleFieldBlur}
            placeholder="0"
            className="full-width-input"
          />
        </td>

        {/* Unit - Dynamic dropdown based on category */}
        <td className="editable-cell">
          <select
            value={localData.unit || availableUnits[0]}
            onChange={(e) => handleFieldChange("unit", e.target.value)}
            className="full-width-select unit-select"
          >
            {availableUnits.map(unit => (
              <option key={unit} value={unit}>
                {unit}
              </option>
            ))}
          </select>
        </td>

        {/* Manufacturing Date */}
        <td className="editable-cell">
          <input
            type="date"
            value={localData.mfg_date || ""}
            onChange={(e) => handleFieldChange("mfg_date", e.target.value)}
            onBlur={handleFieldBlur}
            className="full-width-input"
          />
        </td>

        {/* Expiry Date */}
        <td className="editable-cell">
          <input
            type="date"
            value={localData.expiry_date || ""}
            onChange={(e) => handleFieldChange("expiry_date", e.target.value)}
            onBlur={handleFieldBlur}
            className="full-width-input"
          />
        </td>

        {/* Category - Dropdown */}
        <td className="editable-cell">
          <select
            value={localData.category || "Tablets"}
            onChange={(e) => handleFieldChange("category", e.target.value)}
            className="full-width-select"
          >
            {categoryOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </td>

        {/* Remove Action */}
        <td className="action-cell">
          <button
            className="remove-btn"
            onClick={() => onRemove(medicine.id)}
            type="button"
          >
            ✕
          </button>
        </td>
      </tr>
    );
  });

  // Read-only Row Component for existing medicines
  const ReadOnlyRow = ({ medicine }) => {
    const isEditing = editingCell?.medicineId === medicine.id;
    const getAvailableUnits = (category) => {
      const categoryData = categoryOptions.find(cat => cat.value === category);
      return categoryData ? categoryData.units : ['tablet'];
    };

    const availableUnits = getAvailableUnits(medicine.category);

    return (
      <tr>
        {/* Checkbox - Only show in edit mode */}
        {editMode && (
          <td className="checkbox-cell">
            <input
              type="checkbox"
              checked={selectedRows.has(medicine.id)}
              onChange={() => handleSelectRow(medicine.id)}
            />
          </td>
        )}

        <td className="sku">{medicine.sku}</td>
        
        {/* Medicine Name */}
        <td className="product-name">
          {isEditing && editingCell.field === 'name' ? (
            <div className="inline-edit-container">
              <input
                type="text"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-input"
                autoFocus
              />
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="name-text editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'name', medicine.name)}
            >
              {medicine.name}
            </div>
          )}
        </td>

        {/* Description */}
        <td className="description">
          {isEditing && editingCell.field === 'description' ? (
            <div className="inline-edit-container">
              <input
                type="text"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-input"
                autoFocus
              />
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="description-text editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'description', medicine.description)}
              title={medicine.description}
            >
              {medicine.description}
            </div>
          )}
        </td>

        {/* Unit Price */}
        <td className="price">
          {isEditing && editingCell.field === 'unit_price' ? (
            <div className="inline-edit-container">
              <input
                type="number"
                step="0.01"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-input"
                autoFocus
              />
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'unit_price', medicine.unit_price)}
            >
              {formatCurrency(medicine.unit_price)}
            </div>
          )}
        </td>

        {/* Tax Rate */}
        <td className="tax-rate">
          {isEditing && editingCell.field === 'tax_rate' ? (
            <div className="inline-edit-container">
              <input
                type="number"
                step="0.1"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-input"
                autoFocus
              />
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'tax_rate', medicine.tax_rate)}
            >
              {medicine.tax_rate}%
            </div>
          )}
        </td>

        {/* Stock Quantity */}
        <td className="stock">
          {isEditing && editingCell.field === 'stock_qty' ? (
            <div className="inline-edit-container">
              <input
                type="number"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-input"
                autoFocus
              />
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'stock_qty', medicine.stock_qty)}
            >
              <span className={`stock-badge ${getStockLevelClass(medicine.stock_qty)}`}>
                {medicine.stock_qty} {medicine.unit}{medicine.stock_qty !== 1 ? 's' : ''} · {getStockLevel(medicine.stock_qty)}
              </span>
            </div>
          )}
        </td>

        {/* Unit */}
        <td className="unit">
          {isEditing && editingCell.field === 'unit' ? (
            <div className="inline-edit-container">
              <select
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-select unit-select"
                autoFocus
              >
                {availableUnits.map(unit => (
                  <option key={unit} value={unit}>
                    {unit}
                  </option>
                ))}
              </select>
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'unit', medicine.unit)}
            >
              {medicine.unit}
            </div>
          )}
        </td>

        <td className="expiry-date">{medicine.expiry_date}</td>
        <td className="mfg-date">{medicine.mfg_date}</td>
        
        {/* Category */}
        <td className="category">
          {isEditing && editingCell.field === 'category' ? (
            <div className="inline-edit-container">
              <select
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="inline-edit-select"
                autoFocus
              >
                {categoryOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <div className="inline-edit-actions">
                <button onClick={handleCellSave} className="save-btn">✓</button>
                <button onClick={handleCellCancel} className="cancel-btn">✕</button>
              </div>
            </div>
          ) : (
            <div 
              className="editable-field"
              onClick={() => editMode && handleCellEdit(medicine.id, 'category', medicine.category)}
            >
              {medicine.category}
            </div>
          )}
        </td>
      </tr>
    );
  };

  // Update handler
  const handleRowUpdate = useCallback((id, newData) => {
    setNewRows(prev => 
      prev.map(row => 
        row.id === id ? newData : row
      )
    );
  }, []);

  const visibleData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredData, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  if (isLoading) {
    return <div className="loading">Loading inventory data...</div>;
  }

  return (
    <div className="inventory-container">
      <header className="inventory-header">
        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
        <div className="header-content">
          <h1>Inventory Management</h1>
          <div className="view-options">
            <span className="total-medicines">Total Medicines: {inventoryData.length + newRows.length}</span>
            <div className="action-buttons-group">
              <button className="add-button" onClick={handleAddMedicine}>
                + Add Medicine
              </button>
              {newRows.length > 0 && (
                <>
                  <button className="save-all-button" onClick={handleSaveAll}>
                    Save All ({newRows.length})
                  </button>
                  <button className="cancel-all-button" onClick={handleCancelAll}>
                    Cancel All
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <section className="search-section compact">
        <h3>Search & Filter Medicines</h3>
        
        <div className="search-box-container">
          <div className="search-input-group">
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              placeholder="Search medicines by name or SKU..."
              className="search-input"
            />
            {searchQuery && (
              <button 
                className="clear-search"
                onClick={() => setSearchQuery('')}
              >
                ✕
              </button>
            )}
          </div>
        </div>

        <div className="filters-sort-container">
          <div className="filter-group">
            <select 
              value={selectedCategory} 
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="">All Categories</option>
              {categoryOptions.map(category => (
                <option key={category.value} value={category.value}>
                  {category.label}
                </option>
              ))}
            </select>

            <select 
              value={sortBy === 'stock_level' ? sortOrder : ''} 
              onChange={(e) => handleStockLevelFilter(e.target.value)}
            >
              {stockLevelOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className="sort-group">
            <label>Sort by:</label>
            <select 
              value={sortBy} 
              onChange={(e) => handleSortChange(e.target.value)}
            >
              <option value="name">Name</option>
              <option value="price">Price</option>
              <option value="stock">Stock Quantity</option>
            </select>
            
            <button 
              className={`sort-order-btn ${sortOrder}`}
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            >
            </button>

            <button 
              className={`edit-mode-btn ${editMode ? 'active' : ''}`}
              onClick={() => setEditMode(!editMode)}
            >
              {editMode ? '🔒 Edited' : '✏️ Edit'}
            </button>
          </div>

          {editMode && selectedRows.size > 0 && (
            <div className="selection-actions">
              <span className="selected-count">{selectedRows.size} selected</span>
              <button 
                className="delete-selected-btn"
                onClick={handleDeleteSelected}
              >
                🗑️ Deleted
              </button>
            </div>
          )}
        </div>
      </section>

      <div className="table-wrapper">
        <div className="table-container">
          <table className="inventory-table">
            <thead>
              <tr>
                {/* Checkbox header - Only show in edit mode */}
                {editMode && (
                  <th className="column-checkbox">
                    <input
                      type="checkbox"
                      onChange={handleSelectAll}
                      checked={selectedRows.size === visibleData.length + newRows.length && (visibleData.length + newRows.length) > 0}
                    />
                  </th>
                )}
                <th className="column-sku">SKU</th>
                <th className="column-name sortable" onClick={() => handleSortChange('name')}>
                  Medicine Name {sortBy === 'name' && (sortOrder === 'asc' ? '↑' : '↓')}
                </th>
                <th className="column-description">Description</th>
                <th className="column-price sortable" onClick={() => handleSortChange('price')}>
                  Unit Price {sortBy === 'price' && (sortOrder === 'asc' ? '↑' : '↓')}
                </th>
                <th className="column-tax">Tax Rate</th>
                <th className="column-stock sortable" onClick={() => handleSortChange('stock')}>
                  Stock Qty {sortBy === 'stock' && (sortOrder === 'asc' ? '↑' : '↓')}
                </th>
                <th className="column-unit">Unit</th>
                <th className="column-expiry">Expiry Date</th>
                <th className="column-mfg">MFG Date</th>
                <th className="column-category">Category</th>
                {/* Remove header removed */}
              </tr>
            </thead>
            <tbody>
              {newRows.map((medicine) => (
                <EditableNewRow 
                  key={medicine.id}
                  medicine={medicine}
                  onUpdate={handleRowUpdate}
                  onRemove={handleRemoveNewRow}
                />
              ))}
              
              {visibleData.map((medicine) => (
                <ReadOnlyRow key={medicine.id} medicine={medicine} />
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {totalPages > 1 && (
        <div className="pagination">
          <button 
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
          >
            Previous
          </button>
          
          <span className="page-info">
            Page {currentPage} of {totalPages}
          </span>
          
          <button 
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
          >
            Next
          </button>
        </div>
      )}

      <div className="table-info">
        Showing {visibleData.length} of {filteredData.length} medicines
        {newRows.length > 0 && ` + ${newRows.length} new rows ready to save`}
        {filteredData.length !== inventoryData.length && ` (filtered from ${inventoryData.length} total)`}
        {searchQuery && ` - Searching for: "${searchQuery}"`}
        {editMode && ' - ✏️ Edit Mode: Click on fields to edit'}
      </div>
    </div>
  );
};

export default Inventory;