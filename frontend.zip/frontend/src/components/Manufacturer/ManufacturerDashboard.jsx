// Dashboard.js
import React, { useState } from 'react';
import './ManufacturerDashboard.css';
import Navbar from './Navbar'; 
import {
  DollarSign,
  Factory,
  ClipboardList,
  AlertTriangle
} from "lucide-react";


const ManufacturerDashboard = () => {
   const [activeTab, setActiveTab] = useState('ManufacturerDashboard');
  // Revenue data for the chart
  const revenueData = [
    { month: 'Jan', revenue: 45000 },
    { month: 'Feb', revenue: 53000 },
    { month: 'Mar', revenue: 48000 },
    { month: 'Apr', revenue: 61000 },
    { month: 'May', revenue: 58000 },
    { month: 'Jun', revenue: 72000 },
    { month: 'Jul', revenue: 68000 },
    { month: 'Aug', revenue: 75000 },
    { month: 'Sep', revenue: 69000 },
    { month: 'Oct', revenue: 82000 },
    { month: 'Nov', revenue: 78000 },
    { month: 'Dec', revenue: 88000 }
  ];

  // Production data for line chart
  const productionData = [
    { month: 'Jan', units: 1200 },
    { month: 'Feb', units: 1100 },
    { month: 'Mar', units: 1300 },
    { month: 'Apr', units: 1250 },
    { month: 'May', units: 1400 },
    { month: 'Jun', units: 1350 },
    { month: 'Jul', units: 1500 },
    { month: 'Aug', units: 1450 },
    { month: 'Sep', units: 1600 },
    { month: 'Oct', units: 1550 },
    { month: 'Nov', units: 1650 },
    { month: 'Dec', units: 1600 }
  ];

  // Delivery progress data
  const deliveryData = [
    { id: 'ORD-001', product: 'Medical Masks', status: 'IN TRANSIT', progress: 75, delivery: '2024-01-15' },
    { id: 'ORD-002', product: 'Syringes', status: 'PROCESSING', progress: 30, delivery: '2024-01-18' },
    { id: 'ORD-003', product: 'PPE Kits', status: 'DELIVERED', progress: 100, delivery: '2024-01-10' },
    { id: 'ORD-004', product: 'Ventilators', status: 'PACKAGING', progress: 60, delivery: '2024-01-20' },
    { id: 'ORD-005', product: 'Medications', status: 'IN TRANSIT', progress: 85, delivery: '2024-01-16' }
  ];

  const maxRevenue = Math.max(...revenueData.map(item => item.revenue));
  const maxProduction = Math.max(...productionData.map(item => item.units));
  const minProduction = Math.min(...productionData.map(item => item.units));

  // Calculate line chart path for production volumes
  const getLinePath = () => {
    const points = productionData.map((item, index) => {
      const x = (index / (productionData.length - 1)) * 100;
      const y = 100 - ((item.units - minProduction) / (maxProduction - minProduction)) * 100;
      return `${x},${y}`;
    });
    return `M ${points.join(' L ')}`;
  };

  return (
    <div className="dashboard-container">
      {/* Header Section */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="dashboard-header">
        <div className="header-left">
          <h1>Manufacturing Dashboard</h1>
           </div>
          <div>
           <div className="search-icon">
            <input 
              type="text" 
              className="search-input" 
              placeholder="  Search products, orders, suppliers..." 
            />
          </div></div>
          <div></div>
      </div>

    {/* Main Stats Cards - UPDATED WITH LUCIDE ICONS */}
<div className="stats-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
  {/* Card 1: Total Revenue */}
  <div className="stat-card revenue-card bg-white p-5 rounded-2xl shadow-md hover:shadow-lg transition">
    <div className="card-header flex items-center justify-between">
      <h3 className="text-gray-700 font-semibold flex items-center gap-2">
        <DollarSign className="text-green-600" size={20} />
        Total Revenue
      </h3>
      <div className="card-badge positive bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">+13%</div>
    </div>
    <div className="card-content mt-3">
      <div className="main-value text-3xl font-bold text-gray-900">$8,374</div>
      <div className="card-description text-sm text-gray-500 mt-1">
        Impressive 13% growth from last month
      </div>
    </div>
  </div>

  {/* Card 2: Total Manufactured Product */}
  <div className="stat-card production-card bg-white p-5 rounded-2xl shadow-md hover:shadow-lg transition">
    <div className="card-header flex items-center justify-between">
      <h3 className="text-gray-700 font-semibold flex items-center gap-2">
        <Factory className="text-blue-600" size={20} />
        Total Manufactured
      </h3>
      <div className="card-badge positive bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">+8%</div>
    </div>
    <div className="card-content mt-3">
      <div className="main-value text-3xl font-bold text-gray-900">14,958</div>
      <div className="card-description text-sm text-gray-500 mt-1">
        Units produced year to date
      </div>
    </div>
  </div>

  {/* Card 3: Pending Orders */}
  <div className="stat-card orders-card bg-white p-5 rounded-2xl shadow-md hover:shadow-lg transition">
    <div className="card-header flex items-center justify-between">
      <h3 className="text-gray-700 font-semibold flex items-center gap-2">
        <ClipboardList className="text-amber-500" size={20} />
        Pending Orders
      </h3>
      <div className="card-badge warning bg-amber-100 text-amber-700 px-2 py-1 rounded-full text-xs">+3</div>
    </div>
    <div className="card-content mt-3">
      <div className="main-value text-3xl font-bold text-gray-900">28</div>
      <div className="card-description text-sm text-gray-500 mt-1">
        Orders awaiting processing
      </div>
    </div>
  </div>

  {/* Card 4: Low Stock Alert */}
  <div className="stat-card stock-card bg-white p-5 rounded-2xl shadow-md hover:shadow-lg transition">
    <div className="card-header flex items-center justify-between">
      <h3 className="text-gray-700 font-semibold flex items-center gap-2">
        <AlertTriangle className="text-red-600" size={20} />
        Low Stock Alert
      </h3>
      <div className="card-badge negative bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs">21%</div>
    </div>
    <div className="card-content mt-3">
      <div className="main-value text-3xl font-bold text-gray-900">42</div>
      <div className="card-description text-sm text-gray-500 mt-1">
        Products below threshold
      </div>
    </div>
  </div>
</div>

      {/* Charts and Additional Data Section */}
      <div className="charts-section">
        {/* Revenue Chart */}
        <div className="chart-card">
          <div className="chart-header">
            <h3>Monthly Revenue Analytics</h3>
            <div className="chart-legend">
              <span className="legend-item">
                <span className="legend-color revenue-color"></span>
                Revenue in thousands
              </span>
            </div>
          </div>
          <div className="chart-container">
            <div className="revenue-chart">
              <div className="chart-bars">
                {revenueData.map((item, index) => (
                  <div key={index} className="chart-bar-container">
                    <div 
                      className="chart-bar revenue-bar"
                      style={{ height: `${(item.revenue / maxRevenue) * 80}%` }}
                    >
                      <span className="bar-value">${(item.revenue / 1000).toFixed(0)}K</span>
                    </div>
                    <span className="bar-label">{item.month}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Production Volumes Line Chart */}
        <div className="chart-card">
          <div className="chart-header">
            <h3>Product Production Volumes</h3>
            <div className="chart-legend">
              <span className="legend-item">
                <span className="legend-color production-color"></span>
                Units Produced
              </span>
            </div>
          </div>
          <div className="chart-container">
            <div className="line-chart-container">
              <svg viewBox="0 0 100 100" className="line-chart">
                {/* Grid lines */}
                <line x1="0" y1="0" x2="0" y2="100" stroke="#e2e8f0" strokeWidth="0.5" />
                <line x1="0" y1="100" x2="100" y2="100" stroke="#e2e8f0" strokeWidth="0.5" />
                
                {/* Line path */}
                <path
                  d={getLinePath()}
                  fill="none"
                  stroke="url(#productionGradient)"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                
                {/* Data points */}
                {productionData.map((item, index) => {
                  const x = (index / (productionData.length - 1)) * 100;
                  const y = 100 - ((item.units - minProduction) / (maxProduction - minProduction)) * 100;
                  return (
                    <circle
                      key={index}
                      cx={x}
                      cy={y}
                      r="1.5"
                      fill="#10b981"
                      className="data-point"
                    />
                  );
                })}
                
                {/* Gradient for line */}
                <defs>
                  <linearGradient id="productionGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#34d399" />
                  </linearGradient>
                </defs>
              </svg>
              
              {/* X-axis labels */}
              <div className="line-chart-labels">
                {productionData.map((item, index) => (
                  <span key={index} className="line-chart-label">
                    {item.month}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="production-stats">
            <div className="production-stat">
              <div className="stat-label">Total YTD:</div>
              <div className="stat-value">14,958 units</div>
            </div>
            <div className="production-stat">
              <div className="stat-label">Growth:</div>
              <div className="stat-value positive">+15.2%</div>
            </div>
            <div className="production-stat">
              <div className="stat-label">Peak Month:</div>
              <div className="stat-value">Dec - 1,600 units</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section - Delivery Progress and Additional Metrics */}
      <div className="bottom-section">
        {/* Delivery Progress */}
        <div className="delivery-card large-card">
          <div className="card-header">
            <h3>Delivery in Progress</h3>
            <span className="subtitle">Live order & logistics view</span>
          </div>
          <div className="table-container">
            <table className="delivery-table">
              <thead>
                <tr>
                  <th>ORDER ID</th>
                  <th>PRODUCT</th>
                  <th>STATUS</th>
                  <th>PROGRESS</th>
                  <th>ESTIMATED DELIVERY</th>
                </tr>
              </thead>
              <tbody>
                {deliveryData.map((order, index) => (
                  <tr key={index}>
                    <td className="order-id">{order.id}</td>
                    <td className="product">{order.product}</td>
                    <td>
                      <span className={`status-badge ${order.status.toLowerCase().replace(' ', '-')}`}>
                        {order.status}
                      </span>
                    </td>
                    <td>
                      <div className="progress-bar-container">
                        <div 
                          className="progress-bar"
                          style={{ width: `${order.progress}%` }}
                        ></div>
                        <span className="progress-text">{order.progress}%</span>
                      </div>
                    </td>
                    <td className="delivery-date">{order.delivery}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Additional Metrics */}
        <div className="metrics-sidebar">
          <div className="metric-card">
            <div className="metric-header">
              <h4>Perfect Order Rate</h4>
              <div className="metric-badge excellent">82.6%</div>
            </div>
            <div className="metric-description">
              Your order fulfillment rate is excellent
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-header">
              <h4>Credit Score</h4>
              <div className="metric-badge high">High</div>
            </div>
            <div className="metric-description">
              Your credit score is in excellent standing
            </div>
            <div className="refresh-info">
              REFRESHED ON 16 NOV 2024
            </div>
          </div>

          <div className="metric-card help-card">
            <div className="metric-header">
              <h4>Need Help?</h4>
            </div>
            <div className="metric-description">
              What do these details mean?
            </div>
            <button className="help-btn">
              View Documentation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManufacturerDashboard;