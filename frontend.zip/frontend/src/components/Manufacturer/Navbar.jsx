import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // ✅ Import this
import './Navbar.css';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Truck,
  BarChart3,
  FileText,
  Settings,
} from "lucide-react";
import logo from "../../assets/logo.png";

const Navbar = ({ activeTab, setActiveTab, businessName = "PharmaCorp", onClose }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(3);
  const navigate = useNavigate(); // ✅ React Router hook

  // ✅ Navigation items with proper paths
  const navItems = [
    { key: "ManufacturerDashboard", label: "Dashboard", icon: <LayoutDashboard size={18} />, path: "/Manufacturer/dashboard" },
    { key: "Inventory Management", label: "Inventory Management", icon: <Package size={18} />, path: "/Manufacturer/inventory" },
    { key: "Order Management", label: "Order Management", icon: <ShoppingCart size={18} />, path: "/Manufacturer/orders" },
    { key: "Dispatch & Tracking", label: "Dispatch & Tracking", icon: <Truck size={18} />, path: "/Manufacturer/dispatch" },
    { key: "Reports & Compliance", label: "Reports & Compliance", icon: <BarChart3 size={18} />, path: "/Manufacturer/reports" },
    { key: "settings", label: "Settings", icon: <Settings size={18} />, path: "/Manufacturer/settings" },
  ];

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
    if (!showNotifications) setUnreadNotifications(0);
  };

  // ✅ Navigate to selected route
  const handleNavItemClick = (item) => {
    setActiveTab(item.key);
    setIsSidebarOpen(false);
    navigate(item.path);
  };

  const handleLogout = () => {
    alert('Logging out...');
  };

  const handleClose = () => {
    if (onClose) onClose();
    setIsSidebarOpen(false);
  };

  return (
    <>
      {/* Top Navbar */}
      <nav className="top-navbar">
        <div className="nav-left">
          <button className="hamburger-btn" onClick={toggleSidebar}>
            <span className={`hamburger ${isSidebarOpen ? 'active' : ''}`}>
              <span></span>
              <span></span>
              <span></span>
            </span>
          </button>
          <div className="logo-section">
            <img src={logo} alt="Company Logo" className="logo-img" />
            <span className="company-name">Medi-Care Chain</span>
          </div>
        </div>

        <div className="nav-center">
          <span className="user-role">MANUFACTURER PORTAL</span>
        </div>

        <div className="nav-right">
          <div className="notification-container">
            <button className="notification-btn" onClick={toggleNotifications}>
              <span className="notification-icon">🔔</span>
              {unreadNotifications > 0 && (
                <span className="notification-badge">{unreadNotifications}</span>
              )}
            </button>

            {showNotifications && (
              <div className="notification-dropdown">
                <div className="notification-header">
                  <h3>Notifications</h3>
                  <button className="close-notifications" onClick={toggleNotifications}>×</button>
                </div>
                <div className="notification-list">
                  <div className="notification-item unread">
                    <div className="notification-icon-small">📦</div>
                    <div className="notification-content">
                      <p>New inventory update required</p>
                      <span className="notification-time">2 min ago</span>
                    </div>
                  </div>
                  <div className="notification-item unread">
                    <div className="notification-icon-small">🚚</div>
                    <div className="notification-content">
                      <p>Shipment #4582 delayed</p>
                      <span className="notification-time">1 hour ago</span>
                    </div>
                  </div>
                  <div className="notification-item">
                    <div className="notification-icon-small">📊</div>
                    <div className="notification-content">
                      <p>Weekly report generated</p>
                      <span className="notification-time">Yesterday</span>
                    </div>
                  </div>
                </div>
                <div className="notification-footer">
                  <button className="view-all-notifications">View All Notifications</button>
                </div>
              </div>
            )}
          </div>

          <div className="nav-user">
            <div className="user-avatar">JD</div>
            <div className="user-info">
              <div className="user-name">John Doe</div>
              <div className="user-role-small">Supply Manager</div>
            </div>
          </div>
        </div>
      </nav>

      {/* Sidebar */}
      <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo-content">
            <span className="company-name">Hello {businessName}</span>
          </div>
          <button className="sidebar-close-btn" onClick={handleClose}>×</button>
        </div>

        <div className="sidebar-scrollable">
          <div className="sidebar-nav">
            {navItems.map(item => (
              <button
                key={item.key}
                className={`sidebar-nav-item ${activeTab === item.key ? 'active' : ''}`}
                onClick={() => handleNavItemClick(item)} // ✅ Pass the full item
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            ))}
          </div>

          <div className="sidebar-additional-content">
            <div className="user-info-section">
              <div className="user-avatar-large">JD</div>
              <div className="user-details">
                <div className="user-name-large">John Doe</div>
                <div className="user-role-large">Supply Manager</div>
              </div>
            </div>
          </div>
        </div>

        <div className="sidebar-footer">
          <button className="logout-btn" onClick={handleLogout}>
            <span className="logout-icon">🚪</span>
            <span className="logout-label">Logout</span>
          </button>
        </div>
      </div>

      <div className={`sidebar-overlay ${isSidebarOpen ? 'active' : ''}`} onClick={toggleSidebar} />
    </>
  );
};

export default Navbar;
