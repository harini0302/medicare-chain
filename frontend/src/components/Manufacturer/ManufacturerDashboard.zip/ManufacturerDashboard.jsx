// Dashboard.js - Updated Layout
import React, { useState } from 'react';
import './ManufacturerDashboard.css';
import Navbar from './Navbar'; 
import {
  DollarSign,
  Factory,
  ClipboardList,
  AlertTriangle,
  Calendar,
  Truck,
  CheckCircle,
  Clock
} from "lucide-react";

const ManufacturerDashboard = () => {
  const [activeTab, setActiveTab] = useState('ManufacturerDashboard');
  
  // Revenue data for the line chart
  const [revenueData] = useState([
    { month: "Jan", revenue: 45000 },
    { month: "Feb", revenue: 52000 },
    { month: "Mar", revenue: 58000 },
    { month: "Apr", revenue: 61000 },
    { month: "May", revenue: 69000 },
    { month: "Jun", revenue: 72000 },
    { month: "Jul", revenue: 74000 },
    { month: "Aug", revenue: 80000 },
    { month: "Sep", revenue: 82000 },
    { month: "Oct", revenue: 86000 },
    { month: "Nov", revenue: 87000 },
    { month: "Dec", revenue: 88000 },
  ]);

 const productionData = [
  { month: 'Jan', units: 1200 },
  { month: 'Feb', units: 1100 },
  { month: 'Mar', units: 1300 },
  { month: 'Apr', units: 1250 },
  { month: 'May', units: 1400 },
  { month: 'Jun', units: 1350 },
  { month: 'Jul', units: 1450 },
  { month: 'Aug', units: 1500 },
  { month: 'Sep', units: 1450 },
  { month: 'Oct', units: 1600 },
  { month: 'Nov', units: 1550 },
  { month: 'Dec', units: 1600 },
];


  // Perfect Order Rate data
  const perfectOrderData = [
    { status: 'Pending', orders: 1839, percentage: 85 },
    { status: 'Shipping', orders: 1839, percentage: 70 },
    { status: 'Delivered', orders: 1839, percentage: 45 }
  ];

  const maxRevenue = Math.max(...revenueData.map(item => item.revenue));
  const minRevenue = Math.min(...revenueData.map(item => item.revenue));
  const maxProduction = Math.max(...productionData.map(item => item.units));
// Calculate smooth curved path for revenue - FIXED VERSION
// Calculate smooth curved path for revenue - FIXED: Full width
const getSmoothRevenuePath = () => {
  const points = revenueData.map((item, index) => {
    const x = (index / (revenueData.length - 1)) * 100; // 0% to 100%
    const y = 55 - ((item.revenue - minRevenue) / (maxRevenue - minRevenue)) * 45;
    return { x, y };
  });

  if (points.length === 0) return '';
  
  let path = `M ${points[0].x},${points[0].y}`;
  
  for (let i = 0; i < points.length - 1; i++) {
    const xc = (points[i].x + points[i + 1].x) / 2;
    const yc = (points[i].y + points[i + 1].y) / 2;
    path += ` Q ${points[i].x},${points[i].y} ${xc},${yc}`;
  }
  
  // Connect to the last point
  if (points.length > 1) {
    path += ` Q ${points[points.length - 1].x},${points[points.length - 1].y} ${points[points.length - 1].x},${points[points.length - 1].y}`;
  }
  
  return path;
};

// Calculate area path for under the line - FIXED: Full width
const getRevenueAreaPath = () => {
  const linePath = getSmoothRevenuePath();
  const points = revenueData.map((item, index) => {
    const x = (index / (revenueData.length - 1)) * 100;
    const y = 55 - ((item.revenue - minRevenue) / (maxRevenue - minRevenue)) * 45;
    return { x, y };
  });
  
  if (points.length === 0) return '';
  
  return `${linePath} L ${points[points.length - 1].x},60 L ${points[0].x},60 Z`;
};
  // Get status icon and color
  const getStatusInfo = (status) => {
    switch(status.toLowerCase()) {
      case 'shipping':
        return { icon: <Truck size={16} />, color: '#10b981' };
      case 'delivered':
        return { icon: <CheckCircle size={16} />, color: '#3b82f6' };
      case 'pending':
        return { icon: <Clock size={16} />, color: '#ef4444' };
      default:
        return { icon: <Clock size={16} />, color: '#6b7280' };
    }
  };

  return (
    <div className="dashboard-container">
      {/* Header Section */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="dashboard-header">
        <div className="header-left">
          <h1>Manufacturing Dashboard</h1>
        </div>
        <div>
          <div className="search-icon">
            <input 
              type="text" 
              className="search-input" 
              placeholder="  Search products, orders, suppliers..." 
            />
          </div>
        </div>
        <div></div>
      </div>

      {/* First Row - 4 Stats Cards */}
      <div className="stats-grid">
        {/* Card 1: Total Revenue */}
        <div className="stat-card revenue-card">
          <div className="card-header">
            <h3 className="flex items-center gap-2">
              <DollarSign size={20} />
              Total Revenue
            </h3>
            <div className="card-badge positive">+13%</div>
          </div>
          <div className="card-content">
            <div className="main-value">$8,374</div>
            <div className="card-description">
              Impressive 13% growth from last month
            </div>
          </div>
        </div>

        {/* Card 2: Total Manufactured Product */}
        <div className="stat-card production-card">
          <div className="card-header">
            <h3 className="flex items-center gap-2">
              <Factory size={20} />
              Total Manufactured
            </h3>
            <div className="card-badge positive">+8%</div>
          </div>
          <div className="card-content">
            <div className="main-value">14,958</div>
            <div className="card-description">
              Units produced year to date
            </div>
          </div>
        </div>

        {/* Card 3: Pending Orders */}
        <div className="stat-card orders-card">
          <div className="card-header">
            <h3 className="flex items-center gap-2">
              <ClipboardList size={20} />
              Pending Orders
            </h3>
            <div className="card-badge warning">+3</div>
          </div>
          <div className="card-content">
            <div className="main-value">28</div>
            <div className="card-description">
              Orders awaiting processing
            </div>
          </div>
        </div>

        {/* Card 4: Low Stock Alert */}
        <div className="stat-card stock-card">
          <div className="card-header">
            <h3 className="flex items-center gap-2">
              <AlertTriangle size={20} />
              Low Stock Alert
            </h3>
            <div className="card-badge negative">21%</div>
          </div>
          <div className="card-content">
            <div className="main-value">42</div>
            <div className="card-description">
              Products below threshold
            </div>
          </div>
        </div>
      </div>

      {/* Second Row - Three Main Sections */}
      <div className="main-sections-grid">
        {/* Perfect Order Rate */}
        <div className="section-card perfect-order-section">
          <div className="section-header">
            <h3>Perfect Order Rate</h3>
            <div className="date-display">
              <Calendar size={16} />
              <span>Aug 2024</span>
            </div>
          </div>

          <div className="order-status-breakdown">
            {perfectOrderData.map((item, index) => {
              const statusInfo = getStatusInfo(item.status);
              return (
                <div key={index} className="status-item">
                  <div className="status-main">
                    <div className="status-left">
                      <div className="status-icon" style={{ color: statusInfo.color }}>
                        {statusInfo.icon}
                      </div>
                      <span className="status-name">{item.status}</span>
                    </div>
                    <div className="status-percentage-large">{item.percentage}%</div>
                  </div>
                  <div className="status-details">
                    <span className="status-orders">{item.orders} orders</span>
                    <div className="progress-bar-container">
                      <div 
                        className="progress-bar"
                        style={{ 
                          width: `${item.percentage}%`,
                          backgroundColor: statusInfo.color
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div></div>
{/* Monthly Revenue Section */}
<div className="section-card revenue-section">
  <div className="section-header">
    <h3>Monthly Revenue</h3>
  </div>

  <div className="revenue-chart-container">
    <svg
      viewBox="0 0 100 60"
      preserveAspectRatio="none"
      className="line-chart revenue-line-chart"
    >
      {/* Grid lines */}
      {[10, 20, 30, 40, 50].map((y) => (
        <line key={y} x1="0" y1={y} x2="100" y2={y} className="grid-line" />
      ))}

      {/* Gradient fill under the curve */}
      <path d={getRevenueAreaPath()} className="revenue-area" />

      {/* Smooth wave line */}
      <path
        d={getSmoothRevenuePath()}
        className="revenue-line-path"
        stroke="url(#revenueGradient)"
      />

      <defs>
  <linearGradient id="revenueGradient" x1="0%" y1="0%" x2="100%" y2="0%">
    <stop offset="0%" stopColor="#8b5cf6" />
    <stop offset="50%" stopColor="#3b82f6" />
    <stop offset="100%" stopColor="#10b981" />
  </linearGradient>

  <linearGradient id="revenueAreaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
    <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.2" />
    <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.02" />
  </linearGradient>
</defs>
    </svg>

    {/* Month labels */}
    <div className="month-labels-compact">
      {revenueData.map((item, index) => (
        <span key={index} className="month-label-compact">
          {item.month}
        </span>
      ))}
    </div>
  </div>
</div>



        {/* Product Production Volumes */}
        <div className="section-card production-section">
          <div className="section-header">
            <h3>Product Production Volumes</h3>
            <div className="chart-legend">
              <span className="legend-item">
                <span className="legend-color production-color"></span>
                Units Produced
              </span>
            </div>
          </div>

          <div className="production-chart">
            <div className="chart-bars">
              {productionData.map((item, index) => (
                <div key={index} className="chart-bar-container">
                  <div 
                    className="chart-bar production-bar"
                    style={{ height: `${(item.units / maxProduction) * 80}%` }}
                  >
                    <span className="bar-value">{item.units}</span>
                  </div>
                  <span className="bar-label">{item.month}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="production-stats-grid">
            <div className="production-stat-item">
              <div className="stat-label">Total YTD:</div>
              <div className="stat-value">14,958 units</div>
            </div>
            <div className="production-stat-item">
              <div className="stat-label">Growth:</div>
              <div className="stat-value positive">+15.2%</div>
            </div>
            <div className="production-stat-item">
              <div className="stat-label">Peak Month:</div>
              <div className="stat-value">Dec - 1,600 units</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManufacturerDashboard;