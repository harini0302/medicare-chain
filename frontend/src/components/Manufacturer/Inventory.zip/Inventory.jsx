import React, { useState, useMemo, useEffect, useRef } from "react";
import { LayoutDashboard, Package, ShoppingCart, Truck, BarChart3, Settings, LogOut, Edit, Save, X, Plus, Trash2, ClipboardList, FileText, Mail, Ship, Zap } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import logo from "../../assets/logo.png";
import axios from "axios";

const cn = (...classes) => classes.filter(Boolean).join(' ');

const Inventory = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [inventoryData, setInventoryData] = useState([]);
  const [newRows, setNewRows] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false); 

  // Use useRef for skuCounter to persist across renders
  const skuCounterRef = useRef(1);

  const MEDICINES_API = "http://localhost:8080/api/medicines";
  const COMPANY_API = "http://localhost:8080/api/check-company";

  const fetchMedicines = async () => {
    try {
      setLoading(true);
      // ✅ FIXED: Use MEDICINES_API instead of API_BASE_URL
      const response = await axios.get(MEDICINES_API);
      console.log("Fetched medicines:", response.data);
      setInventoryData(response.data);
      
      // Initialize sku counter based on existing data
      if (response.data.length > 0) {
        const maxSku = response.data.reduce((max, item) => {
          const match = item.sku?.match(/\d+/);
          return match ? Math.max(max, parseInt(match[0])) : max;
        }, 0);
        skuCounterRef.current = maxSku + 1;
      }
    } catch (error) {
      console.error("Error fetching medicines:", error);
      alert("Failed to fetch medicines from server");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMedicines();
  }, []);
  // Add this helper function to handle image URLs properly
const getImageUrl = (imagePath) => {
  if (!imagePath || imagePath === 'No image' || imagePath === 'NULL') return null;
  
  // If it's already a full URL
  if (imagePath.startsWith('http')) return imagePath;
  
  // If it's a blob URL (for previews)
  if (imagePath.startsWith('blob:')) return imagePath;
  
  // If it's a relative path, construct full URL
  if (imagePath.startsWith('/')) {
    return `http://localhost:8080${imagePath}`;
  }
  
  // If it's just a filename, construct path
  return `http://localhost:8080/uploads/${imagePath}`;
};
  // Function to get stock status based on quantity
  const getStockStatus = (stockQty) => {
    if (stockQty < 100) {
      return { status: "Low Stock", color: "text-red-400", bgColor: "bg-red-500/20", borderColor: "border-red-500/50" };
    } else if (stockQty >= 100 && stockQty <= 200) {
      return { status: "Medium Stock", color: "text-yellow-400", bgColor: "bg-yellow-500/20", borderColor: "border-yellow-500/50" };
    } else {
      return { status: "High Stock", color: "text-green-400", bgColor: "bg-green-500/20", borderColor: "border-green-500/50" };
    }
  };

  const checkCompanyVerification = async (email) => {
    try {
      console.log("Making request to check company for email:", email);
      // ✅ FIXED: Use COMPANY_API constant
      const response = await axios.get(`${COMPANY_API}?email=${encodeURIComponent(email)}`);
      console.log("Company check response:", response.data);
      return response.data.exists;
    } catch (error) {
      console.error("Error checking company verification:", error);
      if (error.response) {
        console.error("Response error:", error.response.data);
      }
      return false;
    }
  };

  const categoryOptions = [
    { value: "health devices", label: "Health Devices" },
    { value: "diabetic care", label: "Diabetic Care" },
    { value: "skin care", label: "Skin Care" },
    { value: "womens health", label: "Women's Health" },
    { value: "travel needs", label: "Travel Needs" },
    { value: "supports & braces", label: "Supports & Braces" },
    { value: "heart health", label: "Heart Health" },
    { value: "vitamins and supplements", label: "Vitamins and Supplements" },
    { value: "allergy", label: "Allergy" },
    { value: "baby care", label: "Baby Care" },
    { value: "health drinks", label: "Health Drinks" },
    { value: "oral care", label: "Oral Care" }
  ];

  // Helper function to get units for a category
  const getCategoryUnits = (category) => {
    const categoryMap = {
      "health devices": ["Pieces", "Sets", "Kits"],
      "diabetic care": ["Strips", "Lancets", "Bottles", "Pens", "Cartridges"],
      "skin care": ["Tubes", "Bottles", "Jars", "Pumps", "Packs"],
      "womens health": ["Packs", "Tablets", "Capsules", "Tests", "Bottles"],
      "travel needs": ["Kits", "Packs", "Bottles", "Pieces", "Sets"],
      "supports & braces": ["Pieces", "Pairs", "Sizes", "Sets"],
      "heart health": ["Tablets", "Capsules", "Bottles", "Packs"],
      "vitamins and supplements": ["Tablets", "Capsules", "Softgels", "Bottles", "Packs"],
      "allergy": ["Tablets", "Capsules", "Syrup", "Bottles", "Sprays"],
      "baby care": ["Bottles", "Tubes", "Packs", "Jars", "Pieces"],
      "health drinks": ["Bottles", "Sachets", "Cans", "Packets", "Jars"],
      "oral care": ["Tubes", "Bottles", "Packs", "Pieces", "Brushes"]
    };
    
    return categoryMap[category] || [];
  };

  // Generate SKU - Fixed version
  const generateSKU = (category = "health devices") => {
    const categoryPrefix = category.slice(0, 3).toUpperCase();
    const counter = skuCounterRef.current.toString().padStart(3, "0");
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    skuCounterRef.current += 1;
    return `SKU-${categoryPrefix}-${counter}${random}`;
  };

  // Add new medicine row
  const initializeNewRow = () => {
    const defaultCategory = categoryOptions[0].value;
    const newSku = generateSKU(defaultCategory);

    const defaultUnits = getCategoryUnits(defaultCategory);
    const defaultUnit = defaultUnits.length > 0 ? defaultUnits[0] : "";

    return {
      id: `new-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      sku: newSku,
      name: "",
      category: defaultCategory,
      description: "",
      unit_price: 0,
      stock_qty: 0,
      unit: defaultUnit,
      tax_rate: 0,
      mfg_date: new Date().toISOString().split("T")[0],
      expiry_date: new Date(Date.now() + 31536000000).toISOString().split("T")[0],
      status: "Stock",
      isNew: true,
    };
  };

  const handleAddMedicine = () => {
    setNewRows((prev) => [...prev, initializeNewRow()]);
  };

  const handleSaveAll = async () => {
    if (newRows.length === 0) {
      alert("No new medicines to save.");
      return;
    }

    const user = getUserData();
    console.log("User data in Save All:", user);
    
    if (!user || !user.email) {
      alert("❌ User email not found. Please log in again.");
      return;
    }

    console.log("Checking company verification for:", user.email);
    const isCompanyVerified = await checkCompanyVerification(user.email);
    console.log("Company verification result:", isCompanyVerified);
    
    if (!isCompanyVerified) {
      alert("❌ Please complete company verification before adding medicines. Go to your dashboard to verify your company.");
      return;
    }

    try {
      const savePromises = newRows.map(async (row) => {
        const formData = new FormData();

        // Append image if exists
        if (row.image instanceof File) {
          formData.append("image", row.image);
        }

        // Append all other medicine fields including user email
        const fieldsToAppend = {
          sku: row.sku || "",
          name: row.name || "",
          description: row.description || "",
          unit: row.unit || "",
          unit_price: row.unit_price ? parseFloat(row.unit_price) : 0,
          tax_rate: row.tax_rate ? parseFloat(row.tax_rate) : 0,
          mfg_date: row.mfg_date || "",
          expiry_date: row.expiry_date || "",
          category: row.category || "",
          stock_qty: row.stock_qty ? parseInt(row.stock_qty) : 0,
          status: row.status || "Stock",
          user_email: user.email
        };

        Object.entries(fieldsToAppend).forEach(([key, value]) => {
          // For numeric fields, keep as numbers
          if (['unit_price', 'tax_rate', 'stock_qty'].includes(key)) {
            formData.append(key, value);
          } else {
            formData.append(key, value.toString());
          }
        });

        // ✅ FIXED: Use MEDICINES_API instead of API_BASE_URL
        return await axios.post(MEDICINES_API, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
      });

      const responses = await Promise.all(savePromises);
      const savedMedicines = responses.map((res) => res.data);
      setInventoryData((prev) => [...prev, ...savedMedicines]);
      setNewRows([]);
      alert(`✅ ${savedMedicines.length} medicines saved successfully!`);
    } catch (error) {
      console.error("Error saving medicines:", error);
      if (error.response) {
        alert("❌ Failed to save some medicines: " + (error.response.data?.message || error.response.data));
      } else {
        alert("❌ Failed to save some medicines.");
      }
    }
  };

  // Cancel all unsaved rows
  const handleCancelAll = () => {
    if (newRows.length === 0) return;
    const confirmCancel = window.confirm(
      "Are you sure you want to discard all unsaved rows?"
    );
    if (confirmCancel) {
      setNewRows([]);
    }
  };

  const handleNewRowUpdate = (id, field, value) => {
    setNewRows((prev) => 
      prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
    );
  };

  // Optimize the image upload handler
  const handleImageUpload = (id, file) => {
    if (file) {
      // Check file size (limit to 2MB)
      if (file.size > 2 * 1024 * 1024) {
        alert("❌ Image size should be less than 2MB");
        return;
      }
      
      const imageUrl = URL.createObjectURL(file);
      handleNewRowUpdate(id, "image", file);
      handleNewRowUpdate(id, "imagePreview", imageUrl);
    }
  };

  // Add cleanup effect for blob URLs
  useEffect(() => {
    return () => {
      // Clean up all blob URLs when component unmounts
      newRows.forEach(row => {
        if (row.imagePreview && row.imagePreview.startsWith('blob:')) {
          URL.revokeObjectURL(row.imagePreview);
        }
      });
    };
  }, [newRows]);

  const getUserData = () => {
    try {
      const userData = localStorage.getItem('userData') || sessionStorage.getItem('userData');
      if (!userData) {
        console.log("No user data found in storage");
        return null;
      }
      const parsedData = JSON.parse(userData);
      console.log("User data retrieved:", parsedData);
      return parsedData;
    } catch (error) {
      console.error('Error parsing user data:', error);
      return null;
    }
  };

  const handleSaveNewRow = async (row) => {
  try {
    setSaving(true); 
    console.log("Starting to save row:", row);
    
    const user = getUserData();
    console.log("User data from storage:", user);
    
    if (!user || !user.email) {
      alert("❌ User email not found. Please log in again.");
      return;
    }

    // Add validation for required fields
    if (!row.name || !row.sku) {
      alert("❌ Medicine name and SKU are required fields.");
      return;
    }

    if (row.stock_qty < 0) {
      alert("❌ Stock quantity cannot be negative.");
      return;
    }

    console.log("Checking company verification for:", user.email);
    const isCompanyVerified = await checkCompanyVerification(user.email);
    console.log("Company verification result:", isCompanyVerified);
    
    if (!isCompanyVerified) {
      alert("❌ Please complete company verification before adding medicines. Go to your dashboard to verify your company.");
      return;
    }

    // Continue with saving if company is verified
    const formData = new FormData();
    
    // Append image if exists
    if (row.image instanceof File) {
      console.log("Adding image file:", row.image.name, row.image.size);
      formData.append("image", row.image);
    } else {
      console.log("No image file found");
    }
    
    // Append all other fields including user email
    const fieldsToAppend = {
      sku: row.sku || "",
      name: row.name || "",
      description: row.description || "",
      unit: row.unit || "",
      unit_price: row.unit_price ? parseFloat(row.unit_price) : 0,
      tax_rate: row.tax_rate ? parseFloat(row.tax_rate) : 0,
      mfg_date: row.mfg_date || "",
      expiry_date: row.expiry_date || "",
      category: row.category || "",
      stock_qty: row.stock_qty ? parseInt(row.stock_qty) : 0,
      status: row.status || "Stock",
      user_email: user.email
    };

    console.log("Fields to append - user_email:", fieldsToAppend.user_email);

    // Append each field to FormData
    Object.entries(fieldsToAppend).forEach(([key, value]) => {
      // For numeric fields, keep as numbers
      if (['unit_price', 'tax_rate', 'stock_qty'].includes(key)) {
        formData.append(key, value);
      } else {
        formData.append(key, value.toString());
      }
      console.log(`Appended to FormData: ${key} = ${value}`);
    });

    // Debug: Log FormData contents
    console.log("FormData contents:");
    for (let [key, value] of formData.entries()) {
      if (key === 'image') {
        console.log(key, value.name, value.size, value.type);
      } else {
        console.log(key, value);
      }
    }

    console.log("Sending request to:", MEDICINES_API);
    
    // ✅ FIXED: Use MEDICINES_API instead of API_BASE_URL
    const response = await axios.post(MEDICINES_API, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      timeout: 30000,
    });
     // ✅ CORRECTED: Debug logs should be HERE, after the response
    console.log("Save response received:", response.data);
    console.log("Complete save response:", JSON.stringify(response.data, null, 2));
    console.log("Image field in response:", response.data.image);
    console.log("Response keys:", Object.keys(response.data)); 
   
    
    if (response.data && response.data.id) {
      // Process the image URL from backend response
      let imageUrl = response.data.image;
      
      // If backend returns relative path, construct full URL
      if (imageUrl && !imageUrl.startsWith('http') && !imageUrl.startsWith('blob:')) {
        if (imageUrl.startsWith('/')) {
          imageUrl = `http://localhost:8080${imageUrl}`;
        } else {
          imageUrl = `http://localhost:8080/uploads/${imageUrl}`;
        }
        console.log("Processed image URL:", imageUrl);
      }
       
      // Add the saved medicine to inventory data and remove from new rows
      const savedMedicine = {
        ...row,
        id: response.data.id,
        image: imageUrl, // Use the processed URL
        isNew: false
      };
      
      setInventoryData((prev) => [...prev, savedMedicine]);
      setNewRows((prev) => prev.filter((r) => r.id !== row.id));
      
      // Clean up the blob URL if it exists
      if (row.imagePreview && row.imagePreview.startsWith('blob:')) {
        URL.revokeObjectURL(row.imagePreview);
      }
      
      alert("✅ Medicine saved successfully!");
    } else {
      throw new Error("Invalid response from server");
    }
  } catch (error) {
    console.error("Error saving medicine:", error);
    
    if (error.code === 'ECONNABORTED') {
      alert("❌ Request timeout. The server is taking too long to respond.");
    } else if (error.response) {
      console.error("Response data:", error.response.data);
      console.error("Response status:", error.response.status);
      console.error("Response headers:", error.response.headers);
      alert("❌ Failed to save medicine: " + (error.response.data?.message || error.response.data || error.message));
    } else if (error.request) {
      console.error("Request:", error.request);
      alert("❌ No response received from server. Please check if the server is running.");
    } else {
      alert("❌ Failed to save medicine: " + error.message);
    }
  } finally {
    setSaving(false);
  }
};
  const handleRemoveNewRow = (id) => {
    setNewRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleLogout = () => {
    console.log("Logging out...");
    // Clear any user data from localStorage/sessionStorage if needed
    localStorage.removeItem('userToken');
    localStorage.removeItem('userData');
    sessionStorage.removeItem('userToken');
    
    // Navigate to landing page
    navigate('/');
  };

  // Handle sort change
  const handleSortChange = (newSortBy) => {
    if (sortBy === newSortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(newSortBy);
      setSortOrder('asc');
    }
    setCurrentPage(1);
  };

  // Handle delete selected rows
  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    const confirmDelete = window.confirm(`Delete ${selectedRows.size} selected medicines?`);
    if (!confirmDelete) return;

    try {
      // Delete existing medicines from API
      const existingIds = Array.from(selectedRows).filter(id => !id.toString().startsWith('new-'));
      const deletePromises = existingIds.map(id => 
        // ✅ FIXED: Use MEDICINES_API instead of API_BASE_URL
        axios.delete(`${MEDICINES_API}/${id}`)
      );
      
      await Promise.all(deletePromises);

      // Update UI state
      setInventoryData(prev => prev.filter(item => !selectedRows.has(item.id)));
      setNewRows(prev => prev.filter(row => !selectedRows.has(row.id)));
      setSelectedRows(new Set());
      alert("✅ Selected medicines deleted successfully!");
    } catch (error) {
      console.error("Error deleting medicines:", error);
      alert("❌ Failed to delete some medicines.");
    }
  };

  // Handle select all rows
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      const allIds = new Set([...visibleData.map(item => item.id), ...newRows.map(row => row.id)]);
      setSelectedRows(allIds);
    } else {
      setSelectedRows(new Set());
    }
  };

  // Handle select individual row
  const handleSelectRow = (id) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedRows(newSelected);
  };

  // Handle delete single medicine
  const handleDeleteMedicine = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this medicine?");
    if (!confirmDelete) return;

    try {
      // ✅ FIXED: Use MEDICINES_API instead of API_BASE_URL
      await axios.delete(`${MEDICINES_API}/${id}`);
      setInventoryData(prev => prev.filter(item => item.id !== id));
      alert("✅ Medicine deleted successfully!");
    } catch (error) {
      console.error("Error deleting medicine:", error);
      alert("❌ Failed to delete medicine.");
    }
  };

  // Format currency
  const formatCurrency = (amount) => {
    return `$${parseFloat(amount).toFixed(2)}`;
  };

  // Updated filteredData with sorting
  const filteredData = useMemo(() => {
    let data = [...inventoryData];
    
    if (searchQuery) {
      data = data.filter(
        (i) =>
          i.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.sku?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (selectedCategory) {
      data = data.filter((i) => i.category === selectedCategory);
    }
    
    data.sort((a, b) => {
      let aValue, bValue;
      
      switch (sortBy) {
        case 'name':
          aValue = a.name?.toLowerCase() || '';
          bValue = b.name?.toLowerCase() || '';
          break;
        case 'sku':
          aValue = a.sku?.toLowerCase() || '';
          bValue = b.sku?.toLowerCase() || '';
          break;
        case 'price':
          aValue = a.unit_price || 0;
          bValue = b.unit_price || 0;
          break;
        case 'stock':
          aValue = a.stock_qty || 0;
          bValue = b.stock_qty || 0;
          break;
        case 'category':
          aValue = a.category?.toLowerCase() || '';
          bValue = b.category?.toLowerCase() || '';
          break;
        case 'expiry':
          aValue = new Date(a.expiry_date);
          bValue = new Date(b.expiry_date);
          break;
        default:
          aValue = a.name?.toLowerCase() || '';
          bValue = b.name?.toLowerCase() || '';
      }
      
      if (sortOrder === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });
    
    return data;
  }, [inventoryData, searchQuery, selectedCategory, sortBy, sortOrder]);

  const visibleData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(start, start + itemsPerPage);
  }, [filteredData, currentPage, itemsPerPage]);

  // Navigation items
  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", id: "dashboard" },
    { icon: Package, label: "Inventory Management", id: "inventory" },
    { icon: ClipboardList, label: "Order Management", id: "orders" },
    { icon: Truck, label: "Dispatch & Tracking", id: "dispatch" },
    { icon: FileText, label: "Reports & Compliance", id: "reports" },
  ];

  const bottomItems = [
    { icon: Mail, label: "Emails", id: "emails" },
    { icon: Ship, label: "Shipment", id: "shipment" },
    { icon: Zap, label: "Integration", id: "integration" },
  ];

  const navigate = useNavigate();
  const location = useLocation();
  
  const getActiveItem = () => {
    const path = location.pathname;
    if (path.includes('/inventory')) return 'inventory';
    if (path.includes('/orders')) return 'orders';
    if (path.includes('/dispatch')) return 'dispatch';
    if (path.includes('/reports')) return 'reports';
    if (path.includes('/dashboard')) return 'dashboard';
    return 'inventory';
  };

  const activeItem = getActiveItem();

  const handleNavigation = (itemId) => {
    switch(itemId) {
      case 'dashboard':
        navigate('/manufacturer/dashboard');
        break;
      case 'inventory':
        navigate('/manufacturer/inventory');
        break;
      case 'orders':
        navigate('/manufacturer/orders');
        break;
      case 'dispatch':
        navigate('/manufacturer/dispatch');
        break;
      case 'reports':
        navigate('/manufacturer/reports');
        break;
      default:
        navigate('/manufacturer/dashboard');
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Sidebar */}
      <aside className="w-64 h-screen bg-gray-900 border-r border-gray-700 flex flex-col">
        {/* Logo */}
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden">
            <img 
              src={logo} 
              alt="MediVerse Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <span className="text-xl font-semibold text-white">MediVerse</span>
        </div>

        {/* Main Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavigation(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all cursor-pointer",
                activeItem === item.id
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-500/25"
                  : "text-gray-300 hover:bg-gray-800 hover:text-white"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Bottom Navigation */}
        <nav className="px-3 py-4 space-y-1 border-t border-gray-700">
          {bottomItems.map((item) => (
            <button
              key={item.id}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-gray-300 hover:bg-gray-800 hover:text-white transition-all"
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-gray-700">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-gray-300 hover:bg-red-600 hover:text-white transition-all"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-gray-900 text-white border-b border-gray-700 px-6 py-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white">Inventory Management</h2>
          <div className="flex space-x-3">
            <button
              onClick={handleAddMedicine}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg font-medium text-white transition-all duration-200 flex items-center gap-2"
            >
              <Plus size={18} />
              Add Medicine
            </button>
            {newRows.length > 0 && (
              <>
                <button
                  onClick={handleSaveAll}
                  className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg font-medium text-white transition-all duration-200 flex items-center gap-2"
                >
                  <Save size={18} />
                  Save All ({newRows.length})
                </button>
                <button
                  onClick={handleCancelAll}
                  className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg font-medium text-white transition-all duration-200 flex items-center gap-2"
                >
                  <X size={18} />
                  Cancel All
                </button>
              </>
            )}
          </div>
        </header>

        {/* Search & Filters */}
        <div className="p-4 flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center border-b border-gray-700 bg-gray-900 text-white">
          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-2/4">
            <div className="flex-1 ">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search medicines..."
                className="px-8 py-2 mx-2 my-1 bg-gray-800/50 border border-gray-700 rounded-lg w-full text-white placeholder-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 bg-gray-800/50 border border-gray-700 bg-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent min-w-[180px]"
            >
              <option value="">All Categories</option>
              {categoryOptions.map((cat) => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap gap-3 items-center w-full sm:w-auto">
            <div className="flex items-center gap-2">
              <label className="text-sm text-gray-300 whitespace-nowrap">Sort by:</label>
              <select
                value={sortBy}
                onChange={(e) => handleSortChange(e.target.value)}
                className="px-3 py-2 bg-gray-800/50 border border-gray-700 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="name">Name</option>
                <option value="sku">SKU</option>
                <option value="price">Price</option>
                <option value="stock">Stock</option>
                <option value="category">Category</option>
                <option value="expiry">Expiry Date</option>
                <option value="status">Stock Status</option>
              </select>
              
              <button
                onClick={() => handleSortChange(sortBy)}
                className={`px-3 py-2 bg-gray-800/50 border border-gray-700 bg-gray-700 rounded text-sm text-white hover:bg-gray-600 transition-colors ${
                  sortOrder === 'asc' ? 'text-green-400' : 'text-red-400'
                }`}
                title={sortOrder === 'asc' ? 'Ascending' : 'Descending'}
              >
                {sortOrder === 'asc' ? '↑' : '↓'}
              </button>
            </div>

            <button
              onClick={() => setEditMode(!editMode)}
              className={`px-4 py-2 border rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                editMode
                  ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-500/25'
                  : 'bg-gray-800/50  border-gray-700  text-gray-300 hover:bg-gray-600 hover:text-white'
              }`}
            >
              {editMode ? <Save size={16} /> : <Edit size={16} />}
              {editMode ? 'Done Editing' : 'Edit Mode'}
            </button>

            {editMode && selectedRows.size > 0 && (
              <div className="flex items-center gap-3 bg-red-600/20 border border-red-500/50 rounded-lg px-3 py-2">
                <span className="text-sm text-red-300">{selectedRows.size} selected</span>
                <button
                  onClick={handleDeleteSelected}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm flex items-center gap-2 transition-colors"
                >
                  <Trash2 size={16} />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Table Container */}
        <div className="flex-1 overflow-hidden bg-gray-900 p-4">
          <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden h-full flex flex-col">
            <div className="overflow-auto flex-1">
              <table className="w-full">
                

                
                 <thead className="sticky top-0 bg-gray-800 z-10">
  <tr className="sticky top-0 bg-gray-800">
    {editMode && (
      <th className="px-4 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">
        <input
          type="checkbox"
          onChange={handleSelectAll}
          checked={
            selectedRows.size === visibleData.length + newRows.length &&
            (visibleData.length + newRows.length) > 0
          }
          className="border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500 rounded"
        />
      </th>
    )}
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">SKU</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Image</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Medicine Name</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Description</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Unit</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Unit Price</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Tax Rate</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">MFG Date</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Expiry Date</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Category</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Stock Qty</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Stock Status</th>
    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider sticky top-0 bg-gray-800">Actions</th>
  </tr>
</thead>
                <tbody className="divide-y divide-gray-700">
                  {/* New Rows (Editable) - These appear at the top */}
                  {newRows.map((row) => {
                    const stockStatus = getStockStatus(row.stock_qty);
                    return (
                      <tr key={row.id} className="hover:bg-gray-750 transition-colors bg-blue-900/20">
                        {editMode && (
                          <td className="px-4 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedRows.has(row.id)}
                              onChange={() => handleSelectRow(row.id)}
                              className="border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500 rounded"
                            />
                          </td>
                        )}
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="text"
                            value={row.sku}
                            onChange={(e) => handleNewRowUpdate(row.id, "sku", e.target.value)}
                            className="w-32 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                            placeholder="SKU"
                          />
                        </td>
                        {/* Image Upload Column */}
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUpload(row.id, e.target.files[0])}
                            className="w-32 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                          {row.imagePreview && (
                            <img
                              src={row.imagePreview}
                              alt="preview"
                              className="mt-2 w-16 h-16 object-cover rounded border border-gray-600"
                            />
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="text"
                            placeholder="Medicine name"
                            value={row.name}
                            onChange={(e) => handleNewRowUpdate(row.id, "name", e.target.value)}
                            className="w-40 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <input
                            type="text"
                            placeholder="Description"
                            value={row.description}
                            onChange={(e) => handleNewRowUpdate(row.id, "description", e.target.value)}
                            className="w-48 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <select
                            value={row.unit}
                            onChange={(e) => handleNewRowUpdate(row.id, "unit", e.target.value)}
                            className="w-32 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          >
                            <option value="">Select Unit</option>
                            {getCategoryUnits(row.category).map((unit) => (
                              <option key={unit} value={unit}>
                                {unit}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className="text-gray-400 text-sm">$</span>
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              value={row.unit_price}
                              onChange={(e) => handleNewRowUpdate(row.id, "unit_price", parseFloat(e.target.value) || 0)}
                              className="w-28 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                              placeholder="0.00"
                            />
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              step="0.1"
                              min="0"
                              max="100"
                              value={row.tax_rate}
                              onChange={(e) => handleNewRowUpdate(row.id, "tax_rate", parseFloat(e.target.value) || 0)}
                              className="w-24 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                              placeholder="0.0"
                            />
                            <span className="text-gray-400 text-sm whitespace-nowrap">%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="date"
                            value={row.mfg_date}
                            onChange={(e) => handleNewRowUpdate(row.id, "mfg_date", e.target.value)}
                            className="w-36 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="date"
                            value={row.expiry_date}
                            onChange={(e) => handleNewRowUpdate(row.id, "expiry_date", e.target.value)}
                            className="w-36 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <select
                            value={row.category}
                            onChange={(e) => {
                              handleNewRowUpdate(row.id, "category", e.target.value);
                              handleNewRowUpdate(row.id, "unit", "");
                            }}
                            className="w-40 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          >
                            <option value="">Select Category</option>
                            {categoryOptions.map((c) => (
                              <option key={c.value} value={c.value}>
                                {c.label}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="number"
                            min="0"
                            value={row.stock_qty}
                            onChange={(e) => handleNewRowUpdate(row.id, "stock_qty", parseInt(e.target.value) || 0)}
                            className="w-24 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                            placeholder="0"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${stockStatus.bgColor} ${stockStatus.borderColor} border ${stockStatus.color}`}>
                            {stockStatus.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleSaveNewRow(row)}
                              disabled={saving}
                              className={`bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-white text-sm flex items-center gap-2 transition-colors ${
                                saving ? 'opacity-50 cursor-not-allowed' : ''
                              }`}
                            >
                              {saving ? (
                                <>
                                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                  Saving...
                                </>
                              ) : (
                                <>
                                  <Save size={16} />
                                  Save
                                </>
                              )}
                            </button>
                            <button
                              onClick={() => handleRemoveNewRow(row.id)}
                              className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-white text-sm flex items-center gap-2 transition-colors"
                            >
                              <X size={16} />
                              Cancel
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {/* Existing Data Rows - These show saved medicines */}
                  {visibleData.map((medicine) => {
                    const stockStatus = getStockStatus(medicine.stock_qty);
                    return (
                      <tr key={medicine.id} className="hover:bg-gray-750 transition-colors">
                        {editMode && (
                          <td className="px-4 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedRows.has(medicine.id)}
                              onChange={() => handleSelectRow(medicine.id)}
                              className="rounded border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500"
                            />
                          </td>
                        )}
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                          {medicine.sku}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
  {getImageUrl(medicine.image) ? (
    <div>
      <img
        src={getImageUrl(medicine.image)}
        alt={medicine.name}
        className="w-16 h-16 object-cover rounded border border-gray-600"
        onError={(e) => {
          console.error("❌ Image failed to load:", medicine.image, "Processed URL:", getImageUrl(medicine.image));
          e.target.style.display = 'none';
        }}
        onLoad={(e) => {
          console.log("✅ Image loaded successfully:", getImageUrl(medicine.image));
        }}
      />
    </div>
  ) : (
    <div className="w-16 h-16 bg-gray-700 rounded border border-gray-600 flex items-center justify-center">
      <span className="text-gray-400 text-xs">No Image</span>
    </div>
  )}
</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                          {medicine.name}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-300">
                          {medicine.description}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.unit}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-medium">
                          {formatCurrency(medicine.unit_price)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.tax_rate}%
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.mfg_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.expiry_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.category}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-medium">
                          {medicine.stock_qty}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${stockStatus.bgColor} ${stockStatus.borderColor} border ${stockStatus.color}`}>
                            {stockStatus.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleDeleteMedicine(medicine.id)}
                              className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white text-sm flex items-center gap-1"
                            >
                              <Trash2 size={14} />
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {/* Empty State - Only show when there's no data at all */}
                  {inventoryData.length === 0 && newRows.length === 0 && (
                    <tr>
                      <td colSpan={editMode ? "14" : "13"} className="px-6 py-16 text-center">
                        <div className="text-gray-400 text-6xl mb-4">💊</div>
                        <p className="text-gray-300 text-lg mb-2">No medicines found.</p>
                        <p className="text-gray-500 text-sm">Click "Add Medicine" to get started.</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {filteredData.length > itemsPerPage && (
              <div className="border-t border-gray-700 px-6 py-4 bg-gray-750">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-400">
                    Showing {visibleData.length} of {filteredData.length} medicines
                    {newRows.length > 0 && ` + ${newRows.length} new`}
                  </div>
                  <div className="flex space-x-2">
                    <button
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      className="px-4 py-2 border border-gray-600 rounded-lg text-sm font-medium text-white bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      Previous
                    </button>
                    <span className="px-4 py-2 text-sm text-gray-300 bg-gray-700 border border-gray-600 rounded-lg">
                      Page {currentPage} of {Math.ceil(filteredData.length / itemsPerPage)}
                    </span>
                    <button
                      disabled={currentPage === Math.ceil(filteredData.length / itemsPerPage)}
                      onClick={() => setCurrentPage(prev => Math.min(Math.ceil(filteredData.length / itemsPerPage), prev + 1))}
                      className="px-4 py-2 border border-gray-600 rounded-lg text-sm font-medium text-white bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Inventory;