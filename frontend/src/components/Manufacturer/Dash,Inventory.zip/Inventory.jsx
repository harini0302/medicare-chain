import React, { useState, useMemo, useEffect } from "react";
import {LayoutDashboard,Package,ShoppingCart,Truck,BarChart3,Settings,LogOut,Edit,Save,X,Plus,Trash2,ClipboardList,FileText,Mail,Ship,Zap} from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import logo from "../../assets/logo.png";
import axios from "axios";
const cn = (...classes) => classes.filter(Boolean).join(' ');
const Inventory = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [inventoryData, setInventoryData] = useState([]);
  const [newRows, setNewRows] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [skuCounter, setSkuCounter] = useState(1);
  const [loading, setLoading] = useState(false);

  const API_BASE_URL = "http://localhost:8080/api/medicines";

  const fetchMedicines = async () => {
    try {
      setLoading(true);
      const response = await axios.get(API_BASE_URL);
      console.log("Fetched medicines:", response.data);
      setInventoryData(response.data);
    } catch (error) {
      console.error("Error fetching medicines:", error);
      alert("Failed to fetch medicines from server");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMedicines();
  }, []);

  // Function to get stock status based on quantity
  const getStockStatus = (stockQty) => {
    if (stockQty < 100) {
      return { status: "Low Stock", color: "text-red-400", bgColor: "bg-red-500/20", borderColor: "border-red-500/50" };
    } else if (stockQty >= 100 && stockQty <= 200) {
      return { status: "Medium Stock", color: "text-yellow-400", bgColor: "bg-yellow-500/20", borderColor: "border-yellow-500/50" };
    } else {
      return { status: "High Stock", color: "text-green-400", bgColor: "bg-green-500/20", borderColor: "border-green-500/50" };
    }
  };

  const categoryOptions = [
    { value: "health devices", label: "Health Devices" },
    { value: "diabetic care", label: "Diabetic Care" },
    { value: "skin care", label: "Skin Care" },
    { value: "womens health", label: "Women's Health" },
    { value: "travel needs", label: "Travel Needs" },
    { value: "supports & braces", label: "Supports & Braces" },
    { value: "heart health", label: "Heart Health" },
    { value: "vitamins and supplements", label: "Vitamins and Supplements" },
    { value: "allergy", label: "Allergy" },
    { value: "baby care", label: "Baby Care" },
    { value: "health drinks", label: "Health Drinks" },
    { value: "oral care", label: "Oral Care" }
  ];

  // Helper function to get units for a category
  const getCategoryUnits = (category) => {
    const categoryMap = {
      "health devices": ["Pieces", "Sets", "Kits"],
      "diabetic care": ["Strips", "Lancets", "Bottles", "Pens", "Cartridges"],
      "skin care": ["Tubes", "Bottles", "Jars", "Pumps", "Packs"],
      "womens health": ["Packs", "Tablets", "Capsules", "Tests", "Bottles"],
      "travel needs": ["Kits", "Packs", "Bottles", "Pieces", "Sets"],
      "supports & braces": ["Pieces", "Pairs", "Sizes", "Sets"],
      "heart health": ["Tablets", "Capsules", "Bottles", "Packs"],
      "vitamins and supplements": ["Tablets", "Capsules", "Softgels", "Bottles", "Packs"],
      "allergy": ["Tablets", "Capsules", "Syrup", "Bottles", "Sprays"],
      "baby care": ["Bottles", "Tubes", "Packs", "Jars", "Pieces"],
      "health drinks": ["Bottles", "Sachets", "Cans", "Packets", "Jars"],
      "oral care": ["Tubes", "Bottles", "Packs", "Pieces", "Brushes"]
    };
    
    return categoryMap[category] || [];
  };

  // Generate SKU
  const generateSKU = (category = "health devices") => {
    const categoryPrefix = category.slice(0, 3).toUpperCase();
    const counter = skuCounter.toString().padStart(3, "0");
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `SKU-${categoryPrefix}-${counter}${random}`;
  };

  // Add new medicine row
  const initializeNewRow = () => {
    const defaultCategory = categoryOptions[0].value;
    const newSku = generateSKU(defaultCategory);
    setSkuCounter((prev) => prev + 1);

    const defaultUnits = getCategoryUnits(defaultCategory);
    const defaultUnit = defaultUnits.length > 0 ? defaultUnits[0] : "";

    return {
      id: `new-${Date.now()}`,
      sku: newSku,
      name: "",
      category: defaultCategory,
      description: "",
      unit_price: 0,
      stock_qty: 0,
      unit: defaultUnit,
      tax_rate: 0,
      mfg_date: new Date().toISOString().split("T")[0],
      expiry_date: new Date(Date.now() + 31536000000).toISOString().split("T")[0],
      status: "Stock",
      isNew: true,
    };
  };

  const handleAddMedicine = () => {
    setNewRows((prev) => [...prev, initializeNewRow()]);
  };

  // Save all newly added rows
  const handleSaveAll = async () => {
    if (newRows.length === 0) {
      alert("No new medicines to save.");
      return;
    }

    try {
      const savePromises = newRows.map((row) => 
        axios.post(API_BASE_URL, row)
      );
      
      const responses = await Promise.all(savePromises);
      const savedMedicines = responses.map((res) => res.data);
      
      // Add saved medicines to inventory data and clear new rows
      setInventoryData((prev) => [...prev, ...savedMedicines]);
      setNewRows([]);
      alert(`✅ ${savedMedicines.length} medicines saved successfully!`);
    } catch (error) {
      console.error("Error saving medicines:", error);
      alert("❌ Failed to save some medicines.");
    }
  };

  // Cancel all unsaved rows
  const handleCancelAll = () => {
    if (newRows.length === 0) return;
    const confirmCancel = window.confirm(
      "Are you sure you want to discard all unsaved rows?"
    );
    if (confirmCancel) {
      setNewRows([]);
    }
  };

  const handleNewRowUpdate = (id, field, value) => {
    setNewRows((prev) => 
      prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
    );
  };

  // Save single new row
  const handleSaveNewRow = async (row) => {
    try {
      console.log("Saving row:", row);
      const response = await axios.post(API_BASE_URL, row);
      console.log("Save response:", response.data);
      
      // Add the saved medicine to inventory data and remove from new rows
      setInventoryData((prev) => [...prev, response.data]);
      setNewRows((prev) => prev.filter((r) => r.id !== row.id));
      alert("✅ Medicine saved successfully!");
    } catch (error) {
      console.error("Error saving medicine:", error);
      alert("❌ Failed to save medicine: " + (error.response?.data?.message || error.message));
    }
  };

  const handleRemoveNewRow = (id) => {
    setNewRows((prev) => prev.filter((r) => r.id !== id));
  };

 const handleLogout = () => {
  console.log("Logging out...");
  // Clear any user data from localStorage/sessionStorage if needed
  localStorage.removeItem('userToken');
  localStorage.removeItem('userData');
  sessionStorage.removeItem('userToken');
  
  // Navigate to landing page
  navigate('/');
};

  // Handle sort change
  const handleSortChange = (newSortBy) => {
    if (sortBy === newSortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(newSortBy);
      setSortOrder('asc');
    }
    setCurrentPage(1);
  };

  // Handle delete selected rows
  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    const confirmDelete = window.confirm(`Delete ${selectedRows.size} selected medicines?`);
    if (!confirmDelete) return;

    try {
      // Delete existing medicines from API
      const existingIds = Array.from(selectedRows).filter(id => !id.toString().startsWith('new-'));
      for (const id of existingIds) {
        await axios.delete(`${API_BASE_URL}/${id}`);
      }

      // Update UI state
      setInventoryData(prev => prev.filter(item => !selectedRows.has(item.id)));
      setNewRows(prev => prev.filter(row => !selectedRows.has(row.id)));
      setSelectedRows(new Set());
      alert("✅ Selected medicines deleted successfully!");
    } catch (error) {
      console.error("Error deleting medicines:", error);
      alert("❌ Failed to delete some medicines.");
    }
  };

  // Handle select all rows
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      const allIds = new Set([...visibleData.map(item => item.id), ...newRows.map(row => row.id)]);
      setSelectedRows(allIds);
    } else {
      setSelectedRows(new Set());
    }
  };

  // Handle select individual row
  const handleSelectRow = (id) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedRows(newSelected);
  };

  // Handle delete single medicine
  const handleDeleteMedicine = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this medicine?");
    if (!confirmDelete) return;

    try {
      await axios.delete(`${API_BASE_URL}/${id}`);
      setInventoryData(prev => prev.filter(item => item.id !== id));
      alert("✅ Medicine deleted successfully!");
    } catch (error) {
      console.error("Error deleting medicine:", error);
      alert("❌ Failed to delete medicine.");
    }
  };

  // Format currency
  const formatCurrency = (amount) => {
    return `$${parseFloat(amount).toFixed(2)}`;
  };

  // Updated filteredData with sorting
  const filteredData = useMemo(() => {
    let data = [...inventoryData];
    
    if (searchQuery) {
      data = data.filter(
        (i) =>
          i.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.sku?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (selectedCategory) {
      data = data.filter((i) => i.category === selectedCategory);
    }
    
    data.sort((a, b) => {
      let aValue, bValue;
      
      switch (sortBy) {
        case 'name':
          aValue = a.name?.toLowerCase() || '';
          bValue = b.name?.toLowerCase() || '';
          break;
        case 'sku':
          aValue = a.sku?.toLowerCase() || '';
          bValue = b.sku?.toLowerCase() || '';
          break;
        case 'price':
          aValue = a.unit_price || 0;
          bValue = b.unit_price || 0;
          break;
        case 'stock':
          aValue = a.stock_qty || 0;
          bValue = b.stock_qty || 0;
          break;
        case 'category':
          aValue = a.category?.toLowerCase() || '';
          bValue = b.category?.toLowerCase() || '';
          break;
        case 'expiry':
          aValue = new Date(a.expiry_date);
          bValue = new Date(b.expiry_date);
          break;
        default:
          aValue = a.name?.toLowerCase() || '';
          bValue = b.name?.toLowerCase() || '';
      }
      
      if (sortOrder === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });
    
    return data;
  }, [inventoryData, searchQuery, selectedCategory, sortBy, sortOrder]);

  const visibleData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(start, start + itemsPerPage);
  }, [filteredData, currentPage, itemsPerPage]);

  // Navigation items
  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", id: "dashboard" },
    { icon: Package, label: "Inventory Management", id: "inventory" },
    { icon: ClipboardList, label: "Order Management", id: "orders" },
    { icon: Truck, label: "Dispatch & Tracking", id: "dispatch" },
    { icon: FileText, label: "Reports & Compliance", id: "reports" },
  ];

  const bottomItems = [
    { icon: Mail, label: "Emails", id: "emails" },
    { icon: Ship, label: "Shipment", id: "shipment" },
    { icon: Zap, label: "Integration", id: "integration" },
  ];

  const navigate = useNavigate();
  const location = useLocation();
  
  const getActiveItem = () => {
    const path = location.pathname;
    if (path.includes('/inventory')) return 'inventory';
    if (path.includes('/orders')) return 'orders';
    if (path.includes('/dispatch')) return 'dispatch';
    if (path.includes('/reports')) return 'reports';
    if (path.includes('/dashboard')) return 'dashboard';
    return 'inventory';
  };

  const activeItem = getActiveItem();

  const handleNavigation = (itemId) => {
    switch(itemId) {
      case 'dashboard':
        navigate('/manufacturer/dashboard');
        break;
      case 'inventory':
        navigate('/manufacturer/inventory');
        break;
      case 'orders':
        navigate('/manufacturer/orders');
        break;
      case 'dispatch':
        navigate('/manufacturer/dispatch');
        break;
      case 'reports':
        navigate('/manufacturer/reports');
        break;
      default:
        navigate('/manufacturer/dashboard');
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Sidebar */}
      <aside className="w-64 h-screen bg-gray-900 border-r border-gray-700 flex flex-col">
        {/* Logo */}
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden">
            <img 
              src={logo} 
              alt="MediVerse Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <span className="text-xl font-semibold text-white">MediVerse</span>
        </div>

        {/* Main Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavigation(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all cursor-pointer",
                activeItem === item.id
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-500/25"
                  : "text-gray-300 hover:bg-gray-800 hover:text-white"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Bottom Navigation */}
        <nav className="px-3 py-4 space-y-1 border-t border-gray-700">
          {bottomItems.map((item) => (
            <button
              key={item.id}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-gray-300 hover:bg-gray-800 hover:text-white transition-all"
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-gray-700">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-gray-300 hover:bg-red-600 hover:text-white transition-all"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-gray-900 text-white border-b border-gray-700 px-6 py-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white">Inventory Management</h2>
          <div className="flex space-x-3">
            <button
              onClick={handleAddMedicine}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg font-medium text-white transition-all duration-200 flex items-center gap-2"
            >
              <Plus size={18} />
              Add Medicine
            </button>
            {newRows.length > 0 && (
              <>
                <button
                  onClick={handleSaveAll}
                  className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg font-medium text-white transition-all duration-200 flex items-center gap-2"
                >
                  <Save size={18} />
                  Save All ({newRows.length})
                </button>
                <button
                  onClick={handleCancelAll}
                  className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg font-medium text-white transition-all duration-200 flex items-center gap-2"
                >
                  <X size={18} />
                  Cancel All
                </button>
              </>
            )}
          </div>
        </header>

        {/* Search & Filters */}
        <div className="p-4 flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center border-b border-gray-700 bg-gray-900 text-white">
          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-2/4">
            <div className="flex-1 ">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search medicines..."
                className="px-8 py-2 mx-2 my-1 bg-gray-800/50 border border-gray-700 rounded-lg w-full text-white placeholder-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 bg-gray-800/50 border border-gray-700 bg-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent min-w-[180px]"
            >
              <option value="">All Categories</option>
              {categoryOptions.map((cat) => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap gap-3 items-center w-full sm:w-auto">
            <div className="flex items-center gap-2">
              <label className="text-sm text-gray-300 whitespace-nowrap">Sort by:</label>
              <select
                value={sortBy}
                onChange={(e) => handleSortChange(e.target.value)}
                className="px-3 py-2 bg-gray-800/50 border border-gray-700 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="name">Name</option>
                <option value="sku">SKU</option>
                <option value="price">Price</option>
                <option value="stock">Stock</option>
                <option value="category">Category</option>
                <option value="expiry">Expiry Date</option>
                <option value="status">Stock Status</option>
              </select>
              
              <button
                onClick={() => handleSortChange(sortBy)}
                className={`px-3 py-2 bg-gray-800/50 border border-gray-700 bg-gray-700 rounded text-sm text-white hover:bg-gray-600 transition-colors ${
                  sortOrder === 'asc' ? 'text-green-400' : 'text-red-400'
                }`}
                title={sortOrder === 'asc' ? 'Ascending' : 'Descending'}
              >
                {sortOrder === 'asc' ? '↑' : '↓'}
              </button>
            </div>

            <button
              onClick={() => setEditMode(!editMode)}
              className={`px-4 py-2 border rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                editMode
                  ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-500/25'
                  : 'bg-gray-800/50  border-gray-700  text-gray-300 hover:bg-gray-600 hover:text-white'
              }`}
            >
              {editMode ? <Save size={16} /> : <Edit size={16} />}
              {editMode ? 'Done Editing' : 'Edit Mode'}
            </button>

            {editMode && selectedRows.size > 0 && (
              <div className="flex items-center gap-3 bg-red-600/20 border border-red-500/50 rounded-lg px-3 py-2">
                <span className="text-sm text-red-300">{selectedRows.size} selected</span>
                <button
                  onClick={handleDeleteSelected}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm flex items-center gap-2 transition-colors"
                >
                  <Trash2 size={16} />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Table Container */}
        <div className="flex-1 overflow-hidden bg-gray-900 p-4">
          <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden h-full flex flex-col">
            <div className="overflow-auto flex-1">
              <table className="w-full">
                <thead className="bg-gray-750 border-b border-gray-700 sticky top-0">
                  <tr>
                    {editMode && (
                      <th className="px-4 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">
                        <input
                          type="checkbox"
                          onChange={handleSelectAll}
                          checked={
                            selectedRows.size === visibleData.length + newRows.length &&
                            (visibleData.length + newRows.length) > 0
                          }
                          className="border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500 rounded"
                        />
                      </th>
                    )}
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">SKU</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Medicine Name</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Description</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Unit</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Unit Price</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Tax Rate</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">MFG Date</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Expiry Date</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Stock Qty</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Stock Status</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {/* New Rows (Editable) - These appear at the top */}
                  {newRows.map((row) => {
                    const stockStatus = getStockStatus(row.stock_qty);
                    return (
                      <tr key={row.id} className="hover:bg-gray-750 transition-colors bg-blue-900/20">
                        {editMode && (
                          <td className="px-4 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedRows.has(row.id)}
                              onChange={() => handleSelectRow(row.id)}
                              className="border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500 rounded"
                            />
                          </td>
                        )}
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="text"
                            value={row.sku}
                            onChange={(e) => handleNewRowUpdate(row.id, "sku", e.target.value)}
                            className="w-32 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                            placeholder="SKU"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="text"
                            placeholder="Medicine name"
                            value={row.name}
                            onChange={(e) => handleNewRowUpdate(row.id, "name", e.target.value)}
                            className="w-40 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <input
                            type="text"
                            placeholder="Description"
                            value={row.description}
                            onChange={(e) => handleNewRowUpdate(row.id, "description", e.target.value)}
                            className="w-48 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <select
                            value={row.unit}
                            onChange={(e) => handleNewRowUpdate(row.id, "unit", e.target.value)}
                            className="w-32 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          >
                            <option value="">Select Unit</option>
                            {getCategoryUnits(row.category).map((unit) => (
                              <option key={unit} value={unit}>
                                {unit}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className="text-gray-400 text-sm">$</span>
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              value={row.unit_price}
                              onChange={(e) => handleNewRowUpdate(row.id, "unit_price", parseFloat(e.target.value) || 0)}
                              className="w-28 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                              placeholder="0.00"
                            />
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              step="0.1"
                              min="0"
                              max="100"
                              value={row.tax_rate}
                              onChange={(e) => handleNewRowUpdate(row.id, "tax_rate", parseFloat(e.target.value) || 0)}
                              className="w-24 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                              placeholder="0.0"
                            />
                            <span className="text-gray-400 text-sm whitespace-nowrap">%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="date"
                            value={row.mfg_date}
                            onChange={(e) => handleNewRowUpdate(row.id, "mfg_date", e.target.value)}
                            className="w-36 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="date"
                            value={row.expiry_date}
                            onChange={(e) => handleNewRowUpdate(row.id, "expiry_date", e.target.value)}
                            className="w-36 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <select
                            value={row.category}
                            onChange={(e) => {
                              handleNewRowUpdate(row.id, "category", e.target.value);
                              handleNewRowUpdate(row.id, "unit", "");
                            }}
                            className="w-40 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                          >
                            <option value="">Select Category</option>
                            {categoryOptions.map((c) => (
                              <option key={c.value} value={c.value}>
                                {c.label}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="number"
                            min="0"
                            value={row.stock_qty}
                            onChange={(e) => handleNewRowUpdate(row.id, "stock_qty", parseInt(e.target.value) || 0)}
                            className="w-24 px-3 py-2 border border-gray-600 bg-gray-700 rounded text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                            placeholder="0"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${stockStatus.bgColor} ${stockStatus.borderColor} border ${stockStatus.color}`}>
                            {stockStatus.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleSaveNewRow(row)}
                              className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-white text-sm flex items-center gap-2 transition-colors"
                            >
                              <Save size={16} />
                              Save
                            </button>
                            <button
                              onClick={() => handleRemoveNewRow(row.id)}
                              className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-white text-sm flex items-center gap-2 transition-colors"
                            >
                              <X size={16} />
                              Cancel
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {/* Existing Data Rows - These show saved medicines */}
                  {visibleData.map((medicine) => {
                    const stockStatus = getStockStatus(medicine.stock_qty);
                    return (
                      <tr key={medicine.id} className="hover:bg-gray-750 transition-colors">
                        {editMode && (
                          <td className="px-4 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedRows.has(medicine.id)}
                              onChange={() => handleSelectRow(medicine.id)}
                              className="rounded border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500"
                            />
                          </td>
                        )}
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                          {medicine.sku}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                          {medicine.name}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-300">
                          {medicine.description}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.unit}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-medium">
                          {formatCurrency(medicine.unit_price)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.tax_rate}%
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.mfg_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.expiry_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                          {medicine.category}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-medium">
                          {medicine.stock_qty}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${stockStatus.bgColor} ${stockStatus.borderColor} border ${stockStatus.color}`}>
                            {stockStatus.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleDeleteMedicine(medicine.id)}
                              className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white text-sm flex items-center gap-1"
                            >
                              <Trash2 size={14} />
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {/* Empty State - Only show when there's no data at all */}
                  {inventoryData.length === 0 && newRows.length === 0 && (
                    <tr>
                      <td colSpan={editMode ? "14" : "13"} className="px-6 py-16 text-center">
                        <div className="text-gray-400 text-6xl mb-4">💊</div>
                        <p className="text-gray-300 text-lg mb-2">No medicines found.</p>
                        <p className="text-gray-500 text-sm">Click "Add Medicine" to get started.</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {filteredData.length > itemsPerPage && (
              <div className="border-t border-gray-700 px-6 py-4 bg-gray-750">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-400">
                    Showing {visibleData.length} of {filteredData.length} medicines
                    {newRows.length > 0 && ` + ${newRows.length} new`}
                  </div>
                  <div className="flex space-x-2">
                    <button
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      className="px-4 py-2 border border-gray-600 rounded-lg text-sm font-medium text-white bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      Previous
                    </button>
                    <span className="px-4 py-2 text-sm text-gray-300 bg-gray-700 border border-gray-600 rounded-lg">
                      Page {currentPage} of {Math.ceil(filteredData.length / itemsPerPage)}
                    </span>
                    <button
                      disabled={currentPage === Math.ceil(filteredData.length / itemsPerPage)}
                      onClick={() => setCurrentPage(prev => Math.min(Math.ceil(filteredData.length / itemsPerPage), prev + 1))}
                      className="px-4 py-2 border border-gray-600 rounded-lg text-sm font-medium text-white bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Inventory;